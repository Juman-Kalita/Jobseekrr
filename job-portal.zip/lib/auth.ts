// Mock authentication function for demonstration
// In a real app, this would connect to your actual authentication service

export interface AuthResult {
  success: boolean
  error?: string
  user?: {
    id: string
    email: string
    name: string
    type: "seeker" | "company"
  }
}

export async function authenticateUser(
  email: string,
  password: string,
  userType: "seeker" | "company",
): Promise<AuthResult> {
  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  // Mock validation - in real app, this would be actual authentication
  if (!email || !password) {
    return {
      success: false,
      error: "Email and password are required",
    }
  }

  if (password.length < 6) {
    return {
      success: false,
      error: "Password must be at least 6 characters",
    }
  }

  // Mock successful authentication
  return {
    success: true,
    user: {
      id: Math.random().toString(36).substr(2, 9),
      email,
      name: email.split("@")[0],
      type: userType,
    },
  }
}

export async function registerUser(
  email: string,
  password: string,
  name: string,
  userType: "seeker" | "company",
): Promise<AuthResult> {
  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  // Mock validation
  if (!email || !password || !name) {
    return {
      success: false,
      error: "All fields are required",
    }
  }

  if (password.length < 6) {
    return {
      success: false,
      error: "Password must be at least 6 characters",
    }
  }

  // Mock successful registration
  return {
    success: true,
    user: {
      id: Math.random().toString(36).substr(2, 9),
      email,
      name,
      type: userType,
    },
  }
}
