"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Briefcase, Search, Bell, Sun, Moon, Menu, User, Settings, LogOut, Heart, FileText } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [notifications, setNotifications] = useState(3)
  const router = useRouter()
  const { toast } = useToast()

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode)
    toast({
      title: "Theme Changed",
      description: `Switched to ${!isDarkMode ? "dark" : "light"} mode`,
    })
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      router.push(`/jobs?searchTerm=${encodeURIComponent(searchQuery)}`)
      setSearchQuery("")
    }
  }

  const handleNotificationClick = () => {
    setNotifications(0)
    toast({
      title: "Notifications",
      description: "You have 3 new notifications",
    })
  }

  const handleLogout = () => {
    localStorage.removeItem("authToken")
    toast({
      title: "Logged Out",
      description: "You have been successfully logged out",
    })
    router.push("/")
  }

  const handleProfileClick = (action: string) => {
    switch (action) {
      case "dashboard":
        router.push("/dashboard/seeker")
        break
      case "profile":
        router.push("/profile")
        break
      case "applied":
        router.push("/applied")
        break
      case "saved":
        router.push("/saved")
        break
      case "settings":
        toast({
          title: "Settings",
          description: "Settings page coming soon!",
        })
        break
      default:
        break
    }
  }

  return (
    <header className="bg-white/90 backdrop-blur-sm shadow-lg border-b border-orange-100 sticky top-0 z-50">
      <div className="container mx-auto py-4 px-5 flex items-center justify-between">
        {/* Logo */}
        <Link
          href="/"
          className="flex items-center space-x-2 text-2xl font-bold text-gray-800 hover:text-orange-600 transition-colors"
        >
          <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-red-500 rounded-lg flex items-center justify-center">
            <Briefcase className="h-5 w-5 text-white" />
          </div>
          <span>CareerBoost</span>
        </Link>

        {/* Search Bar (Desktop) */}
        <form onSubmit={handleSearch} className="hidden md:flex flex-1 max-w-md mx-8">
          <div className="relative w-full">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search jobs, companies..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 border-orange-200 focus:border-orange-500 focus:ring-orange-500"
            />
          </div>
        </form>

        {/* Navigation (Desktop) */}
        <nav className="hidden md:flex space-x-6">
          <Link href="/jobs" className="text-gray-600 hover:text-orange-600 font-medium transition-colors">
            Jobs
          </Link>
          <Link href="/companies" className="text-gray-600 hover:text-orange-600 font-medium transition-colors">
            Companies
          </Link>
          <Link href="/salary-guide" className="text-gray-600 hover:text-orange-600 font-medium transition-colors">
            Salary Guide
          </Link>
          <Link href="/resources" className="text-gray-600 hover:text-orange-600 font-medium transition-colors">
            Resources
          </Link>
        </nav>

        {/* Actions */}
        <div className="flex items-center space-x-4">
          {/* Theme Toggle */}
          <Button variant="ghost" size="icon" onClick={toggleTheme} className="hover:bg-orange-50">
            {isDarkMode ? <Sun className="h-5 w-5 text-orange-600" /> : <Moon className="h-5 w-5 text-orange-600" />}
          </Button>

          {/* Notifications */}
          <Button variant="ghost" size="icon" onClick={handleNotificationClick} className="relative hover:bg-orange-50">
            <Bell className="h-5 w-5 text-orange-600" />
            {notifications > 0 && (
              <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-red-500 text-white text-xs flex items-center justify-center">
                {notifications}
              </span>
            )}
          </Button>

          {/* Profile Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="flex items-center space-x-2 hover:bg-orange-50">
                <Avatar className="h-8 w-8">
                  <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Profile" />
                  <AvatarFallback className="bg-gradient-to-br from-orange-500 to-red-500 text-white">
                    JD
                  </AvatarFallback>
                </Avatar>
                <span className="text-gray-700 font-medium hidden md:block">John Doe</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuItem onClick={() => handleProfileClick("dashboard")}>
                <User className="mr-2 h-4 w-4" />
                Dashboard
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleProfileClick("profile")}>
                <User className="mr-2 h-4 w-4" />
                Profile
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleProfileClick("applied")}>
                <FileText className="mr-2 h-4 w-4" />
                Applied Jobs
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleProfileClick("saved")}>
                <Heart className="mr-2 h-4 w-4" />
                Saved Jobs
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => handleProfileClick("settings")}>
                <Settings className="mr-2 h-4 w-4" />
                Settings
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleLogout} className="text-red-600">
                <LogOut className="mr-2 h-4 w-4" />
                Log out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Mobile Menu */}
          <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden hover:bg-orange-50">
                <Menu className="h-5 w-5 text-orange-600" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-80">
              <div className="flex flex-col space-y-6 mt-6">
                {/* Mobile Search */}
                <form onSubmit={handleSearch}>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Search jobs..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10 border-orange-200 focus:border-orange-500"
                    />
                  </div>
                </form>

                {/* Mobile Navigation */}
                <nav className="flex flex-col space-y-4">
                  <Link
                    href="/jobs"
                    className="text-gray-600 hover:text-orange-600 font-medium transition-colors"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Jobs
                  </Link>
                  <Link
                    href="/companies"
                    className="text-gray-600 hover:text-orange-600 font-medium transition-colors"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Companies
                  </Link>
                  <Link
                    href="/salary-guide"
                    className="text-gray-600 hover:text-orange-600 font-medium transition-colors"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Salary Guide
                  </Link>
                  <Link
                    href="/resources"
                    className="text-gray-600 hover:text-orange-600 font-medium transition-colors"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Resources
                  </Link>
                </nav>

                {/* Mobile Actions */}
                <div className="space-y-3">
                  <Button
                    className="w-full bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white"
                    onClick={() => {
                      router.push("/login")
                      setIsMenuOpen(false)
                    }}
                  >
                    Sign In
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full border-orange-300 text-orange-600 hover:bg-orange-50"
                    onClick={() => {
                      router.push("/register")
                      setIsMenuOpen(false)
                    }}
                  >
                    Sign Up
                  </Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}
