"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Briefcase,
  Users,
  Eye,
  Calendar,
  MapPin,
  TrendingUp,
  Bell,
  Target,
  Award,
  Clock,
  ArrowRight,
  Plus,
  DollarSign,
  Filter,
  LogIn,
  Shield,
  UserCheck,
  FileText,
} from "lucide-react"

export default function CompanyDashboardPage() {
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("overview")

  // Mock company data
  const company = {
    name: "TechCorp Inc.",
    industry: "Technology",
    size: "201-500 employees",
    location: "San Francisco, CA",
    logo: "https://images.unsplash.com/photo-1549923746-c502d488b3ea?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80",
    memberSince: "January 2024",
    planType: "Premium",
  }

  const stats = [
    {
      label: "Active Job Posts",
      value: "12",
      change: "+3 this month",
      icon: Briefcase,
      color: "text-orange-500",
      bgColor: "bg-orange-500/10",
      trend: "up",
    },
    {
      label: "Total Applications",
      value: "284",
      change: "+45 this week",
      icon: FileText,
      color: "text-green-500",
      bgColor: "bg-green-500/10",
      trend: "up",
    },
    {
      label: "Candidates Hired",
      value: "18",
      change: "+5 this month",
      icon: UserCheck,
      color: "text-blue-500",
      bgColor: "bg-blue-500/10",
      trend: "up",
    },
    {
      label: "Response Rate",
      value: "89%",
      change: "+12% improvement",
      icon: TrendingUp,
      color: "text-purple-500",
      bgColor: "bg-purple-500/10",
      trend: "up",
    },
  ]

  const recentApplications = [
    {
      id: 1,
      candidateName: "Sarah Johnson",
      position: "Senior Frontend Developer",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=60&h=60&fit=crop&crop=face",
      appliedDate: "2 hours ago",
      status: "New Application",
      statusColor: "bg-blue-500",
      experience: "5+ years",
      location: "San Francisco, CA",
      matchScore: 95,
      skills: ["React", "TypeScript", "Next.js"],
    },
    {
      id: 2,
      candidateName: "Michael Chen",
      position: "Product Manager",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=60&h=60&fit=crop&crop=face",
      appliedDate: "1 day ago",
      status: "Interview Scheduled",
      statusColor: "bg-green-500",
      experience: "7+ years",
      location: "Remote",
      matchScore: 88,
      skills: ["Product Strategy", "Analytics", "Leadership"],
    },
    {
      id: 3,
      candidateName: "Emily Davis",
      position: "UX Designer",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=60&h=60&fit=crop&crop=face",
      appliedDate: "3 days ago",
      status: "Under Review",
      statusColor: "bg-yellow-500",
      experience: "4+ years",
      location: "New York, NY",
      matchScore: 92,
      skills: ["Figma", "User Research", "Prototyping"],
    },
  ]

  const activeJobs = [
    {
      id: 1,
      title: "Senior Frontend Developer",
      department: "Engineering",
      posted: "5 days ago",
      applications: 45,
      views: 234,
      status: "Active",
      salary: "$120k - $150k",
      type: "Full-time",
      location: "San Francisco, CA",
    },
    {
      id: 2,
      title: "Product Manager",
      department: "Product",
      posted: "1 week ago",
      applications: 67,
      views: 189,
      status: "Active",
      salary: "$130k - $160k",
      type: "Full-time",
      location: "Remote",
    },
    {
      id: 3,
      title: "UX Designer",
      department: "Design",
      posted: "2 weeks ago",
      applications: 32,
      views: 156,
      status: "Active",
      salary: "$90k - $120k",
      type: "Full-time",
      location: "New York, NY",
    },
  ]

  const upcomingInterviews = [
    {
      id: 1,
      candidateName: "Sarah Johnson",
      position: "Senior Frontend Developer",
      date: "Today",
      time: "2:00 PM",
      type: "Technical Interview",
      interviewer: "John Smith",
      avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=60&h=60&fit=crop&crop=face",
    },
    {
      id: 2,
      candidateName: "Michael Chen",
      position: "Product Manager",
      date: "Tomorrow",
      time: "10:00 AM",
      type: "Final Interview",
      interviewer: "Jane Doe",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=60&h=60&fit=crop&crop=face",
    },
  ]

  // Mock authentication check
  useEffect(() => {
    const checkAuth = async () => {
      await new Promise((resolve) => setTimeout(resolve, 1000))
      const authStatus = true
      setIsAuthenticated(authStatus)
      setIsLoading(false)
    }
    checkAuth()
  }, [])

  // Show loading state
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-red-50">
        <Header />
        <div className="container mx-auto px-4 py-16 text-center">
          <div className="max-w-md mx-auto space-y-6">
            <div className="w-20 h-20 bg-gradient-to-br from-orange-500 to-red-500 rounded-2xl flex items-center justify-center mx-auto animate-pulse">
              <div className="w-10 h-10 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            </div>
            <div className="space-y-2">
              <h3 className="text-2xl font-bold text-gray-900">Loading Dashboard...</h3>
              <p className="text-gray-600">Checking your authentication status</p>
            </div>
          </div>
        </div>
      </div>
    )
  }

  // Show authentication required message
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-red-50">
        <Header />
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-2xl mx-auto text-center space-y-8">
            <div className="w-24 h-24 bg-red-500/10 rounded-2xl flex items-center justify-center mx-auto">
              <Shield className="h-12 w-12 text-red-500" />
            </div>

            <div className="space-y-4">
              <h1 className="text-4xl font-bold text-gray-900">Authentication Required</h1>
              <p className="text-xl text-gray-600">You need to sign in to access your company dashboard</p>
            </div>

            <Card className="border-0 shadow-xl bg-white/90 backdrop-blur-sm max-w-md mx-auto">
              <CardContent className="p-8 space-y-6">
                <div className="text-center">
                  <h3 className="text-lg font-semibold mb-2 text-gray-900">Access Your Dashboard</h3>
                  <p className="text-sm text-gray-600">
                    Sign in to manage your job postings, review applications, and find top talent
                  </p>
                </div>

                <div className="space-y-3">
                  <Button
                    className="w-full bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white font-semibold shadow-lg"
                    asChild
                  >
                    <Link href="/login">
                      <LogIn className="mr-2 h-5 w-5" />
                      Sign In
                    </Link>
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full border-orange-300 text-orange-600 hover:bg-orange-50"
                    asChild
                  >
                    <Link href="/register">Create Account</Link>
                  </Button>
                </div>

                <div className="text-center">
                  <Button variant="ghost" className="text-sm text-gray-600" onClick={() => router.push("/")}>
                    ← Back to Welcome
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-red-50">
      <Header />

      <div className="container mx-auto px-4 py-8">
        {/* Welcome Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-6">
              <Avatar className="w-20 h-20 ring-4 ring-orange-200">
                <AvatarImage src={company.logo || "/placeholder.svg"} alt={company.name} />
                <AvatarFallback className="text-2xl bg-gradient-to-br from-orange-500 to-red-500 text-white">
                  {company.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </AvatarFallback>
              </Avatar>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Welcome back, {company.name}! 🏢</h1>
                <p className="text-gray-600 text-lg">
                  {company.industry} • {company.size} • {company.location}
                </p>
                <div className="flex items-center space-x-4 mt-2">
                  <Badge variant="secondary" className="bg-gradient-to-r from-green-500 to-teal-500 text-white">
                    {company.planType} Plan
                  </Badge>
                  <Badge variant="outline" className="border-orange-300 text-orange-600">
                    Member since {company.memberSince}
                  </Badge>
                </div>
              </div>
            </div>
            <div className="text-right">
              <Button
                className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white shadow-lg"
                asChild
              >
                <Link href="/company/post-job">
                  <Plus className="h-4 w-4 mr-2" />
                  Post New Job
                </Link>
              </Button>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card
              key={index}
              className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white/80 backdrop-blur-sm"
            >
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className={`w-12 h-12 ${stat.bgColor} rounded-xl flex items-center justify-center`}>
                    <stat.icon className={`h-6 w-6 ${stat.color}`} />
                  </div>
                  <Badge variant="secondary" className="bg-gradient-to-r from-green-500 to-teal-500 text-white text-xs">
                    {stat.trend === "up" ? "↗" : "↘"} {stat.change}
                  </Badge>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">{stat.label}</p>
                  <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <TabsTrigger
              value="overview"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white"
            >
              <TrendingUp className="h-4 w-4 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger
              value="applications"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white"
            >
              <Users className="h-4 w-4 mr-2" />
              Applications
            </TabsTrigger>
            <TabsTrigger
              value="jobs"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white"
            >
              <Briefcase className="h-4 w-4 mr-2" />
              Job Posts
            </TabsTrigger>
            <TabsTrigger
              value="interviews"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white"
            >
              <Calendar className="h-4 w-4 mr-2" />
              Interviews
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-8">
              {/* Quick Actions */}
              <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center text-gray-900">
                    <Target className="h-5 w-5 mr-2 text-orange-500" />
                    Quick Actions
                  </CardTitle>
                  <CardDescription>Manage your hiring process</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button
                    className="w-full justify-start bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white shadow-lg"
                    asChild
                  >
                    <Link href="/company/post-job">
                      <Plus className="h-4 w-4 mr-2" />
                      Post New Job
                    </Link>
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start border-orange-300 text-orange-600 hover:bg-orange-50"
                    asChild
                  >
                    <Link href="/company/applications">
                      <Users className="h-4 w-4 mr-2" />
                      Review Applications
                    </Link>
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start border-orange-300 text-orange-600 hover:bg-orange-50"
                    asChild
                  >
                    <Link href="/company/jobs">
                      <Briefcase className="h-4 w-4 mr-2" />
                      Manage Job Posts
                    </Link>
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start border-orange-300 text-orange-600 hover:bg-orange-50"
                    asChild
                  >
                    <Link href="/company/analytics">
                      <TrendingUp className="h-4 w-4 mr-2" />
                      View Analytics
                    </Link>
                  </Button>
                </CardContent>
              </Card>

              {/* Recent Activity */}
              <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center text-gray-900">
                    <Bell className="h-5 w-5 mr-2 text-blue-500" />
                    Recent Activity
                  </CardTitle>
                  <CardDescription>Latest updates on your job posts</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-3 p-3 rounded-lg bg-green-50">
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900">New application received!</p>
                      <p className="text-xs text-gray-600">Senior Frontend Developer • 2 hours ago</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 rounded-lg bg-blue-50">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900">Interview completed</p>
                      <p className="text-xs text-gray-600">Product Manager position • 1 day ago</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 rounded-lg bg-purple-50">
                    <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900">Job post published</p>
                      <p className="text-xs text-gray-600">UX Designer role • 3 days ago</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Hiring Insights */}
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center text-gray-900">
                  <Award className="h-5 w-5 mr-2 text-yellow-500" />
                  Hiring Insights
                </CardTitle>
                <CardDescription>Performance metrics for your job posts</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="text-center p-4 rounded-lg bg-gradient-to-br from-orange-50 to-red-50">
                    <div className="text-2xl font-bold text-orange-600 mb-2">3.2 days</div>
                    <div className="text-sm text-gray-600">Average time to hire</div>
                    <div className="text-xs text-green-600 mt-1">↗ 15% faster than industry</div>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-gradient-to-br from-green-50 to-teal-50">
                    <div className="text-2xl font-bold text-green-600 mb-2">89%</div>
                    <div className="text-sm text-gray-600">Application response rate</div>
                    <div className="text-xs text-green-600 mt-1">↗ +12% vs last month</div>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-gradient-to-br from-purple-50 to-pink-50">
                    <div className="text-2xl font-bold text-purple-600 mb-2">4.8/5</div>
                    <div className="text-sm text-gray-600">Candidate satisfaction</div>
                    <div className="text-xs text-blue-600 mt-1">Based on 45 reviews</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="applications" className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-2xl font-semibold text-gray-900">Recent Applications</h3>
              <Button variant="outline" className="border-orange-300 text-orange-600 hover:bg-orange-50" asChild>
                <Link href="/company/applications">
                  <Filter className="h-4 w-4 mr-2" />
                  View All Applications
                </Link>
              </Button>
            </div>

            <div className="grid gap-6">
              {recentApplications.map((application, index) => (
                <Card
                  key={application.id}
                  className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white/80 backdrop-blur-sm"
                >
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-4 flex-1">
                        <Avatar className="w-16 h-16">
                          <AvatarImage src={application.avatar || "/placeholder.svg"} alt={application.candidateName} />
                          <AvatarFallback className="bg-gradient-to-br from-orange-500 to-red-500 text-white">
                            {application.candidateName
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h4 className="text-xl font-semibold text-gray-900">{application.candidateName}</h4>
                            <Badge className={`${application.statusColor} text-white`}>{application.status}</Badge>
                            <Badge
                              variant="outline"
                              className="bg-gradient-to-r from-green-500 to-teal-500 text-white border-0"
                            >
                              {application.matchScore}% match
                            </Badge>
                          </div>
                          <p className="text-gray-600 mb-2">Applied for: {application.position}</p>
                          <div className="flex items-center text-sm text-gray-600 space-x-4 mb-3">
                            <div className="flex items-center">
                              <MapPin className="h-4 w-4 mr-1" />
                              {application.location}
                            </div>
                            <div className="flex items-center">
                              <Award className="h-4 w-4 mr-1" />
                              {application.experience}
                            </div>
                            <div className="flex items-center">
                              <Clock className="h-4 w-4 mr-1" />
                              Applied {application.appliedDate}
                            </div>
                          </div>
                          <div className="flex flex-wrap gap-1">
                            {application.skills.map((skill) => (
                              <Badge
                                key={skill}
                                variant="outline"
                                className="text-xs border-orange-300 text-orange-600"
                              >
                                {skill}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                      <div className="flex flex-col space-y-2">
                        <Button
                          className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white shadow-lg"
                          asChild
                        >
                          <Link href={`/company/candidates/${application.id}`}>
                            View Profile
                            <ArrowRight className="ml-2 h-4 w-4" />
                          </Link>
                        </Button>
                        <Button variant="outline" className="border-orange-300 text-orange-600 hover:bg-orange-50">
                          Schedule Interview
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="jobs" className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-2xl font-semibold text-gray-900">Active Job Posts</h3>
              <Button
                className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white shadow-lg"
                asChild
              >
                <Link href="/company/post-job">
                  <Plus className="h-4 w-4 mr-2" />
                  Post New Job
                </Link>
              </Button>
            </div>

            <div className="grid gap-6">
              {activeJobs.map((job, index) => (
                <Card
                  key={job.id}
                  className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white/80 backdrop-blur-sm"
                >
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h4 className="text-xl font-semibold text-gray-900">{job.title}</h4>
                          <Badge className="bg-green-500 text-white">{job.status}</Badge>
                          <Badge variant="outline" className="border-orange-300 text-orange-600">
                            {job.department}
                          </Badge>
                        </div>
                        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
                          <div className="flex items-center text-sm text-gray-600">
                            <Eye className="h-4 w-4 mr-1" />
                            {job.views} views
                          </div>
                          <div className="flex items-center text-sm text-gray-600">
                            <Users className="h-4 w-4 mr-1" />
                            {job.applications} applications
                          </div>
                          <div className="flex items-center text-sm text-gray-600">
                            <MapPin className="h-4 w-4 mr-1" />
                            {job.location}
                          </div>
                          <div className="flex items-center text-sm text-gray-600">
                            <Clock className="h-4 w-4 mr-1" />
                            Posted {job.posted}
                          </div>
                        </div>
                        <div className="flex items-center text-lg font-bold text-gray-900">
                          <DollarSign className="h-4 w-4 mr-1" />
                          {job.salary} • {job.type}
                        </div>
                      </div>
                      <div className="flex flex-col space-y-2">
                        <Button
                          className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white shadow-lg"
                          asChild
                        >
                          <Link href={`/company/jobs/${job.id}`}>
                            View Details
                            <ArrowRight className="ml-2 h-4 w-4" />
                          </Link>
                        </Button>
                        <Button variant="outline" className="border-orange-300 text-orange-600 hover:bg-orange-50">
                          Edit Job
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="interviews" className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-2xl font-semibold text-gray-900">Upcoming Interviews</h3>
              <Button variant="outline" className="border-orange-300 text-orange-600 hover:bg-orange-50">
                <Calendar className="h-4 w-4 mr-2" />
                Schedule Interview
              </Button>
            </div>

            {upcomingInterviews.length > 0 ? (
              <div className="grid gap-6">
                {upcomingInterviews.map((interview, index) => (
                  <Card
                    key={interview.id}
                    className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white/80 backdrop-blur-sm"
                  >
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <Avatar className="w-16 h-16">
                            <AvatarImage src={interview.avatar || "/placeholder.svg"} alt={interview.candidateName} />
                            <AvatarFallback className="bg-gradient-to-br from-orange-500 to-red-500 text-white">
                              {interview.candidateName
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <h4 className="text-xl font-semibold mb-1 text-gray-900">{interview.candidateName}</h4>
                            <p className="text-gray-600 mb-2">{interview.position}</p>
                            <div className="flex items-center space-x-4 text-sm">
                              <div className="flex items-center text-green-600 font-medium">
                                <Calendar className="h-4 w-4 mr-1" />
                                {interview.date} at {interview.time}
                              </div>
                              <Badge variant="secondary" className="bg-orange-100 text-orange-600">
                                {interview.type}
                              </Badge>
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-gray-600 mb-2">Interviewer</p>
                          <p className="font-medium text-gray-900">{interview.interviewer}</p>
                          <Button className="mt-3 bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white shadow-lg">
                            Join Interview
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                <CardContent className="p-12 text-center">
                  <Calendar className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                  <h3 className="text-lg font-semibold mb-2 text-gray-900">No Upcoming Interviews</h3>
                  <p className="text-gray-600 mb-4">Schedule interviews with your top candidates</p>
                  <Button
                    className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white shadow-lg"
                    asChild
                  >
                    <Link href="/company/applications">Review Applications</Link>
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
