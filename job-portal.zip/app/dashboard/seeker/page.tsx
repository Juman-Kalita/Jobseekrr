"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Briefcase,
  Eye,
  Heart,
  Calendar,
  MapPin,
  TrendingUp,
  Star,
  Bell,
  Target,
  Award,
  Users,
  Clock,
  ArrowRight,
  Plus,
  BookOpen,
  Zap,
  DollarSign,
  Filter,
  LogIn,
  Shield,
} from "lucide-react"

export default function SeekerDashboardPage() {
  const router = useRouter()
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("overview")

  // Mock user data
  const user = {
    name: "John Doe",
    email: "john@example.com",
    avatar:
      "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80",
    title: "Senior Frontend Developer",
    location: "San Francisco, CA",
    experience: "5+ years",
    profileComplete: 85,
    memberSince: "January 2024",
  }

  const stats = [
    {
      label: "Applications Sent",
      value: "23",
      change: "+5 this week",
      icon: Briefcase,
      color: "text-orange-500",
      bgColor: "bg-orange-500/10",
      trend: "up",
    },
    {
      label: "Profile Views",
      value: "156",
      change: "+12% this month",
      icon: Eye,
      color: "text-green-500",
      bgColor: "bg-green-500/10",
      trend: "up",
    },
    {
      label: "Saved Jobs",
      value: "8",
      change: "2 new matches",
      icon: Heart,
      color: "text-red-500",
      bgColor: "bg-red-500/10",
      trend: "up",
    },
    {
      label: "Interview Rate",
      value: "34%",
      change: "+8% improvement",
      icon: TrendingUp,
      color: "text-yellow-500",
      bgColor: "bg-yellow-500/10",
      trend: "up",
    },
  ]

  const recentApplications = [
    {
      id: 1,
      title: "Senior Frontend Developer",
      company: "TechCorp Inc.",
      logo: "https://images.unsplash.com/photo-1549923746-c502d488b3ea?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80",
      appliedDate: "2 days ago",
      status: "Under Review",
      statusColor: "bg-yellow-500",
      salary: "$120k - $150k",
      location: "San Francisco, CA",
      matchScore: 95,
    },
    {
      id: 2,
      title: "Product Engineer",
      company: "StartupXYZ",
      logo: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80",
      appliedDate: "1 week ago",
      status: "Interview Scheduled",
      statusColor: "bg-green-500",
      salary: "$110k - $140k",
      location: "Remote",
      matchScore: 88,
    },
    {
      id: 3,
      title: "React Developer",
      company: "WebStudio",
      logo: "https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80",
      appliedDate: "2 weeks ago",
      status: "Rejected",
      statusColor: "bg-red-500",
      salary: "$90k - $120k",
      location: "New York, NY",
      matchScore: 76,
    },
  ]

  const recommendedJobs = [
    {
      id: 1,
      title: "Senior React Developer",
      company: "InnovateTech",
      logo: "https://images.unsplash.com/photo-1549923746-c502d488b3ea?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&q=80",
      location: "Remote",
      salary: "$130k - $160k",
      type: "Full-time",
      matchScore: 96,
      posted: "1 day ago",
      skills: ["React", "TypeScript", "Next.js"],
      urgent: true,
    },
    {
      id: 2,
      title: "Frontend Architect",
      company: "DesignCorp",
      logo: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&q=80",
      location: "San Francisco, CA",
      salary: "$140k - $170k",
      type: "Full-time",
      matchScore: 92,
      posted: "3 days ago",
      skills: ["React", "Vue.js", "Architecture"],
      urgent: false,
    },
    {
      id: 3,
      title: "Lead Frontend Engineer",
      company: "TechFlow",
      logo: "https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&q=80",
      location: "Austin, TX",
      salary: "$125k - $155k",
      type: "Full-time",
      matchScore: 89,
      posted: "5 days ago",
      skills: ["React", "Node.js", "Leadership"],
      urgent: false,
    },
  ]

  const upcomingInterviews = [
    {
      id: 1,
      company: "TechCorp Inc.",
      position: "Senior Frontend Developer",
      date: "Tomorrow",
      time: "2:00 PM",
      type: "Video Call",
      interviewer: "Sarah Johnson",
      logo: "https://images.unsplash.com/photo-1549923746-c502d488b3ea?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&q=80",
    },
    {
      id: 2,
      company: "StartupXYZ",
      position: "Product Engineer",
      date: "Friday",
      time: "10:00 AM",
      type: "In-person",
      interviewer: "Mike Chen",
      logo: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&q=80",
    },
  ]

  const learningResources = [
    {
      title: "Advanced React Patterns",
      provider: "TechEd",
      duration: "4 hours",
      level: "Advanced",
      image:
        "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80",
      progress: 60,
    },
    {
      title: "System Design Interview Prep",
      provider: "CodeMaster",
      duration: "6 hours",
      level: "Expert",
      image:
        "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80",
      progress: 25,
    },
  ]

  // Mock authentication check
  useEffect(() => {
    // Simulate auth check
    const checkAuth = async () => {
      await new Promise((resolve) => setTimeout(resolve, 1000))
      // In real app, this would check actual auth state
      const authStatus = true // Change to true to simulate logged in user
      setIsAuthenticated(authStatus)
      setIsLoading(false)
    }
    checkAuth()
  }, [])

  // Show loading state
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-red-50">
        <Header />
        <div className="container mx-auto px-4 py-16 text-center">
          <div className="max-w-md mx-auto space-y-6">
            <div className="w-20 h-20 bg-gradient-to-br from-orange-500 to-red-500 rounded-2xl flex items-center justify-center mx-auto animate-pulse">
              <div className="w-10 h-10 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            </div>
            <div className="space-y-2">
              <h3 className="text-2xl font-bold text-gray-900">Loading Dashboard...</h3>
              <p className="text-gray-600">Checking your authentication status</p>
            </div>
          </div>
        </div>
      </div>
    )
  }

  // Show authentication required message
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-red-50">
        <Header />
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-2xl mx-auto text-center space-y-8">
            <div className="w-24 h-24 bg-red-500/10 rounded-2xl flex items-center justify-center mx-auto">
              <Shield className="h-12 w-12 text-red-500" />
            </div>

            <div className="space-y-4">
              <h1 className="text-4xl font-bold text-gray-900">Authentication Required</h1>
              <p className="text-xl text-gray-600">You need to sign in to access your job seeker dashboard</p>
            </div>

            <Card className="border-0 shadow-xl bg-white/90 backdrop-blur-sm max-w-md mx-auto">
              <CardContent className="p-8 space-y-6">
                <div className="text-center">
                  <h3 className="text-lg font-semibold mb-2 text-gray-900">Access Your Dashboard</h3>
                  <p className="text-sm text-gray-600">
                    Sign in to view your applications, saved jobs, and personalized recommendations
                  </p>
                </div>

                <div className="space-y-3">
                  <Button
                    className="w-full bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white font-semibold shadow-lg"
                    asChild
                  >
                    <Link href="/login">
                      <LogIn className="mr-2 h-5 w-5" />
                      Sign In
                    </Link>
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full border-orange-300 text-orange-600 hover:bg-orange-50"
                    asChild
                  >
                    <Link href="/register">Create Account</Link>
                  </Button>
                </div>

                <div className="text-center">
                  <Button variant="ghost" className="text-sm text-gray-600" onClick={() => router.push("/")}>
                    ← Back to Welcome
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Preview of what they'll get */}
            <div className="grid md:grid-cols-3 gap-6 mt-12">
              <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-orange-500/10 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <Briefcase className="h-6 w-6 text-orange-500" />
                  </div>
                  <h4 className="font-semibold mb-2 text-gray-900">Track Applications</h4>
                  <p className="text-sm text-gray-600">Monitor all your job applications in one place</p>
                </CardContent>
              </Card>
              <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-green-500/10 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <Star className="h-6 w-6 text-green-500" />
                  </div>
                  <h4 className="font-semibold mb-2 text-gray-900">AI Job Matching</h4>
                  <p className="text-sm text-gray-600">Get personalized job recommendations</p>
                </CardContent>
              </Card>
              <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 bg-purple-500/10 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <Calendar className="h-6 w-6 text-purple-500" />
                  </div>
                  <h4 className="font-semibold mb-2 text-gray-900">Interview Scheduler</h4>
                  <p className="text-sm text-gray-600">Manage your interview schedule</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-red-50">
      <Header />

      <div className="container mx-auto px-4 py-8">
        {/* Welcome Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-6">
              <Avatar className="w-20 h-20 ring-4 ring-orange-200">
                <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
                <AvatarFallback className="text-2xl bg-gradient-to-br from-orange-500 to-red-500 text-white">
                  {user.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </AvatarFallback>
              </Avatar>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Welcome back, {user.name.split(" ")[0]}! 👋</h1>
                <p className="text-gray-600 text-lg">
                  {user.title} • {user.location}
                </p>
                <div className="flex items-center space-x-4 mt-2">
                  <Badge variant="secondary" className="bg-gradient-to-r from-green-500 to-teal-500 text-white">
                    {user.experience} experience
                  </Badge>
                  <Badge variant="outline" className="border-orange-300 text-orange-600">
                    Member since {user.memberSince}
                  </Badge>
                </div>
              </div>
            </div>
            <div className="text-right">
              <Button
                className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white shadow-lg"
                asChild
              >
                <Link href="/jobs">
                  <Briefcase className="h-4 w-4 mr-2" />
                  Browse Jobs
                </Link>
              </Button>
            </div>
          </div>
        </div>

        {/* Profile Completion */}
        {user.profileComplete < 100 && (
          <Card className="mb-8 border-orange-200 bg-gradient-to-r from-orange-50 to-yellow-50 border-0 shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-orange-500/20 rounded-xl flex items-center justify-center">
                    <Target className="h-6 w-6 text-orange-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-orange-800">Complete Your Profile to Get Better Matches</h3>
                    <p className="text-sm text-orange-600">
                      {user.profileComplete}% complete - Add skills and experience to stand out
                    </p>
                  </div>
                </div>
                <Button variant="outline" className="border-orange-200 hover:bg-orange-100 text-orange-600" asChild>
                  <Link href="/profile">Complete Profile</Link>
                </Button>
              </div>
              <Progress value={user.profileComplete} className="h-3" />
            </CardContent>
          </Card>
        )}

        {/* Stats Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card
              key={index}
              className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white/80 backdrop-blur-sm"
            >
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className={`w-12 h-12 ${stat.bgColor} rounded-xl flex items-center justify-center`}>
                    <stat.icon className={`h-6 w-6 ${stat.color}`} />
                  </div>
                  <Badge variant="secondary" className="bg-gradient-to-r from-green-500 to-teal-500 text-white text-xs">
                    {stat.trend === "up" ? "↗" : "↘"} {stat.change}
                  </Badge>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">{stat.label}</p>
                  <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-5 bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <TabsTrigger
              value="overview"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white"
            >
              <TrendingUp className="h-4 w-4 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger
              value="applications"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white"
            >
              <Briefcase className="h-4 w-4 mr-2" />
              Applications
            </TabsTrigger>
            <TabsTrigger
              value="recommended"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white"
            >
              <Star className="h-4 w-4 mr-2" />
              For You
            </TabsTrigger>
            <TabsTrigger
              value="interviews"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white"
            >
              <Calendar className="h-4 w-4 mr-2" />
              Interviews
            </TabsTrigger>
            <TabsTrigger
              value="learning"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white"
            >
              <BookOpen className="h-4 w-4 mr-2" />
              Learning
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-8">
              {/* Quick Actions */}
              <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center text-gray-900">
                    <Zap className="h-5 w-5 mr-2 text-yellow-500" />
                    Quick Actions
                  </CardTitle>
                  <CardDescription>Get started with your job search</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button
                    className="w-full justify-start bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white shadow-lg"
                    asChild
                  >
                    <Link href="/jobs">
                      <Briefcase className="h-4 w-4 mr-2" />
                      Browse New Jobs
                    </Link>
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start border-orange-300 text-orange-600 hover:bg-orange-50"
                    asChild
                  >
                    <Link href="/profile">
                      <Users className="h-4 w-4 mr-2" />
                      Update Profile
                    </Link>
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start border-orange-300 text-orange-600 hover:bg-orange-50"
                    asChild
                  >
                    <Link href="/saved">
                      <Heart className="h-4 w-4 mr-2" />
                      View Saved Jobs
                    </Link>
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start border-orange-300 text-orange-600 hover:bg-orange-50"
                    asChild
                  >
                    <Link href="/salary">
                      <DollarSign className="h-4 w-4 mr-2" />
                      Salary Insights
                    </Link>
                  </Button>
                </CardContent>
              </Card>

              {/* Recent Activity */}
              <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center text-gray-900">
                    <Bell className="h-5 w-5 mr-2 text-blue-500" />
                    Recent Activity
                  </CardTitle>
                  <CardDescription>Latest updates on your applications</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-3 p-3 rounded-lg bg-green-50">
                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900">Interview scheduled!</p>
                      <p className="text-xs text-gray-600">TechCorp Inc. • Tomorrow at 2:00 PM</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 rounded-lg bg-blue-50">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900">Application viewed</p>
                      <p className="text-xs text-gray-600">StartupXYZ • 3 hours ago</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 rounded-lg bg-purple-50">
                    <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900">New job match found</p>
                      <p className="text-xs text-gray-600">96% match • 1 day ago</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Job Market Insights */}
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center text-gray-900">
                  <Award className="h-5 w-5 mr-2 text-yellow-500" />
                  Job Market Insights
                </CardTitle>
                <CardDescription>Trends in your field</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="text-center p-4 rounded-lg bg-gradient-to-br from-orange-50 to-red-50">
                    <div className="text-2xl font-bold text-orange-600 mb-2">2,340</div>
                    <div className="text-sm text-gray-600">Frontend jobs this month</div>
                    <div className="text-xs text-green-600 mt-1">↗ +15% vs last month</div>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-gradient-to-br from-green-50 to-teal-50">
                    <div className="text-2xl font-bold text-green-600 mb-2">$125k</div>
                    <div className="text-sm text-gray-600">Average salary in SF</div>
                    <div className="text-xs text-green-600 mt-1">↗ +8% vs last year</div>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-gradient-to-br from-purple-50 to-pink-50">
                    <div className="text-2xl font-bold text-purple-600 mb-2">Remote</div>
                    <div className="text-sm text-gray-600">Most popular work type</div>
                    <div className="text-xs text-blue-600 mt-1">67% of all postings</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="applications" className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-2xl font-semibold text-gray-900">Your Applications</h3>
              <Button variant="outline" className="border-orange-300 text-orange-600 hover:bg-orange-50" asChild>
                <Link href="/applied">
                  <Filter className="h-4 w-4 mr-2" />
                  View All Applications
                </Link>
              </Button>
            </div>

            <div className="grid gap-6">
              {recentApplications.map((application, index) => (
                <Card
                  key={application.id}
                  className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white/80 backdrop-blur-sm"
                >
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-4 flex-1">
                        <Image
                          src={application.logo || "/placeholder.svg"}
                          alt={application.company}
                          width={60}
                          height={60}
                          className="rounded-xl"
                        />
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h4 className="text-xl font-semibold text-gray-900">{application.title}</h4>
                            <Badge className={`${application.statusColor} text-white`}>{application.status}</Badge>
                            <Badge
                              variant="outline"
                              className="bg-gradient-to-r from-green-500 to-teal-500 text-white border-0"
                            >
                              {application.matchScore}% match
                            </Badge>
                          </div>
                          <p className="text-gray-600 mb-2">{application.company}</p>
                          <div className="flex items-center text-sm text-gray-600 space-x-4">
                            <div className="flex items-center">
                              <MapPin className="h-4 w-4 mr-1" />
                              {application.location}
                            </div>
                            <div className="flex items-center">
                              <DollarSign className="h-4 w-4 mr-1" />
                              {application.salary}
                            </div>
                            <div className="flex items-center">
                              <Clock className="h-4 w-4 mr-1" />
                              Applied {application.appliedDate}
                            </div>
                          </div>
                        </div>
                      </div>
                      <Button
                        className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white shadow-lg"
                        asChild
                      >
                        <Link href={`/jobs/${application.id}`}>
                          View Details
                          <ArrowRight className="ml-2 h-4 w-4" />
                        </Link>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="recommended" className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-2xl font-semibold text-gray-900">Recommended for You</h3>
                <p className="text-gray-600">AI-powered job matches based on your profile</p>
              </div>
              <Button variant="outline" className="border-orange-300 text-orange-600 hover:bg-orange-50" asChild>
                <Link href="/jobs">
                  <Star className="h-4 w-4 mr-2" />
                  Browse All Jobs
                </Link>
              </Button>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {recommendedJobs.map((job, index) => (
                <Card
                  key={job.id}
                  className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white/80 backdrop-blur-sm relative"
                >
                  {job.urgent && (
                    <div className="absolute -top-2 -right-2 z-10">
                      <Badge className="bg-gradient-to-r from-red-500 to-pink-500 text-white animate-pulse">
                        URGENT
                      </Badge>
                    </div>
                  )}
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-3 mb-4">
                      <Image
                        src={job.logo || "/placeholder.svg"}
                        alt={job.company}
                        width={50}
                        height={50}
                        className="rounded-lg"
                      />
                      <div className="flex-1">
                        <h4 className="font-semibold text-lg text-gray-900">{job.title}</h4>
                        <p className="text-sm text-gray-600">{job.company}</p>
                      </div>
                      <Badge
                        variant="outline"
                        className="bg-gradient-to-r from-green-500 to-teal-500 text-white border-0"
                      >
                        {job.matchScore}% match
                      </Badge>
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center text-sm text-gray-600">
                        <MapPin className="h-4 w-4 mr-2" />
                        {job.location}
                      </div>
                      <div className="flex items-center text-lg font-bold text-gray-900">
                        <DollarSign className="h-4 w-4 mr-1" />
                        {job.salary}
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {job.skills.map((skill) => (
                          <Badge key={skill} variant="outline" className="text-xs border-orange-300 text-orange-600">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                      <div className="flex items-center justify-between pt-2">
                        <div className="flex items-center text-xs text-gray-600">
                          <Clock className="h-3 w-3 mr-1" />
                          {job.posted}
                        </div>
                        <Button
                          size="sm"
                          className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white shadow-lg"
                          asChild
                        >
                          <Link href={`/jobs/${job.id}`}>
                            Apply Now
                            <ArrowRight className="ml-2 h-4 w-4" />
                          </Link>
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="interviews" className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-2xl font-semibold text-gray-900">Upcoming Interviews</h3>
              <Button variant="outline" className="border-orange-300 text-orange-600 hover:bg-orange-50">
                <Calendar className="h-4 w-4 mr-2" />
                Add to Calendar
              </Button>
            </div>

            {upcomingInterviews.length > 0 ? (
              <div className="grid gap-6">
                {upcomingInterviews.map((interview, index) => (
                  <Card
                    key={interview.id}
                    className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white/80 backdrop-blur-sm"
                  >
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <Image
                            src={interview.logo || "/placeholder.svg"}
                            alt={interview.company}
                            width={60}
                            height={60}
                            className="rounded-xl"
                          />
                          <div>
                            <h4 className="text-xl font-semibold mb-1 text-gray-900">{interview.position}</h4>
                            <p className="text-gray-600 mb-2">{interview.company}</p>
                            <div className="flex items-center space-x-4 text-sm">
                              <div className="flex items-center text-green-600 font-medium">
                                <Calendar className="h-4 w-4 mr-1" />
                                {interview.date} at {interview.time}
                              </div>
                              <Badge variant="secondary" className="bg-orange-100 text-orange-600">
                                {interview.type}
                              </Badge>
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-gray-600 mb-2">Interviewer</p>
                          <p className="font-medium text-gray-900">{interview.interviewer}</p>
                          <Button className="mt-3 bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white shadow-lg">
                            Join Interview
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                <CardContent className="p-12 text-center">
                  <Calendar className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                  <h3 className="text-lg font-semibold mb-2 text-gray-900">No Upcoming Interviews</h3>
                  <p className="text-gray-600 mb-4">Keep applying to jobs to schedule interviews</p>
                  <Button
                    className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white shadow-lg"
                    asChild
                  >
                    <Link href="/jobs">Browse Jobs</Link>
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="learning" className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-2xl font-semibold text-gray-900">Skill Development</h3>
                <p className="text-gray-600">Enhance your skills to get better job matches</p>
              </div>
              <Button variant="outline" className="border-orange-300 text-orange-600 hover:bg-orange-50">
                <Plus className="h-4 w-4 mr-2" />
                Browse Courses
              </Button>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              {learningResources.map((resource, index) => (
                <Card
                  key={index}
                  className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white/80 backdrop-blur-sm"
                >
                  <div className="relative">
                    <Image
                      src={resource.image || "/placeholder.svg"}
                      alt={resource.title}
                      width={400}
                      height={200}
                      className="w-full h-48 object-cover rounded-t-lg"
                    />
                    <div className="absolute top-4 right-4">
                      <Badge className="bg-gradient-to-r from-orange-500 to-red-500 text-white">{resource.level}</Badge>
                    </div>
                  </div>
                  <CardContent className="p-6">
                    <h4 className="font-semibold text-lg mb-2 text-gray-900">{resource.title}</h4>
                    <p className="text-sm text-gray-600 mb-4">
                      by {resource.provider} • {resource.duration}
                    </p>
                    <div className="space-y-2 mb-4">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">Progress</span>
                        <span className="text-gray-900">{resource.progress}%</span>
                      </div>
                      <Progress value={resource.progress} className="h-2" />
                    </div>
                    <Button className="w-full bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white shadow-lg">
                      Continue Learning
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
