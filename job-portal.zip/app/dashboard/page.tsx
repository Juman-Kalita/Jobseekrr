"use client"

import { useState, useRef, Suspense } from "react"
import { Canvas, useFrame } from "@react-three/fiber"
import { OrbitControls, Text3D, Environment, Float, Stars } from "@react-three/drei"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Users, Building2, ArrowRight, Sparkles, Zap, Shield, Globe, CheckCircle, UserPlus } from "lucide-react"
import Link from "next/link"
import type * as THREE from "three"

// 3D Floating Elements
function FloatingElement({
  position,
  color,
  shape = "sphere",
}: { position: [number, number, number]; color: string; shape?: string }) {
  const meshRef = useRef<THREE.Mesh>(null)

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.x = Math.sin(state.clock.elapsedTime) * 0.3
      meshRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.5) * 0.3
      meshRef.current.position.y = position[1] + Math.sin(state.clock.elapsedTime * 2) * 0.5
    }
  })

  return (
    <Float speed={2} rotationIntensity={1} floatIntensity={2}>
      <mesh ref={meshRef} position={position}>
        {shape === "sphere" && <sphereGeometry args={[0.5, 32, 32]} />}
        {shape === "box" && <boxGeometry args={[1, 1, 1]} />}
        {shape === "cylinder" && <cylinderGeometry args={[0.5, 0.5, 1, 32]} />}
        <meshStandardMaterial color={color} transparent opacity={0.8} />
      </mesh>
    </Float>
  )
}

// 3D Logo
function Logo3D() {
  return (
    <Float speed={1} rotationIntensity={0.5} floatIntensity={1}>
      <Text3D font="/fonts/Inter_Bold.json" size={1.5} height={0.3} position={[-3, 4, 0]}>
        JobPortal
        <meshStandardMaterial color="#6366f1" />
      </Text3D>
    </Float>
  )
}

// 3D Scene
function Scene3D() {
  return (
    <>
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} intensity={1} />
      <pointLight position={[-10, -10, -10]} intensity={0.5} color="#ff6b6b" />

      <Logo3D />

      {/* Floating Elements */}
      <FloatingElement position={[-8, 2, -5]} color="#6366f1" shape="sphere" />
      <FloatingElement position={[8, 1, -3]} color="#8b5cf6" shape="box" />
      <FloatingElement position={[-6, -2, -4]} color="#06b6d4" shape="cylinder" />
      <FloatingElement position={[6, -1, -6]} color="#10b981" shape="sphere" />
      <FloatingElement position={[0, 3, -8]} color="#f59e0b" shape="box" />
      <FloatingElement position={[-4, -3, -2]} color="#ef4444" shape="cylinder" />

      <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />

      <Environment preset="city" />
    </>
  )
}

// Main Component
export default function SignupPage() {
  const [selectedRole, setSelectedRole] = useState<"seeker" | "company" | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  const handleSignup = (role: "seeker" | "company") => {
    setIsLoading(true)
    setSelectedRole(role)

    // Simulate signup process
    setTimeout(() => {
      setIsLoading(false)
      // Redirect to appropriate dashboard
      window.location.href = role === "seeker" ? "/dashboard/seeker" : "/dashboard/company"
    }, 2000)
  }

  if (isLoading) {
    return (
      <div className="w-full h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
        <Canvas camera={{ position: [0, 0, 10], fov: 75 }}>
          <Suspense fallback={null}>
            <ambientLight intensity={0.5} />
            <pointLight position={[10, 10, 10]} intensity={1} />

            <Float speed={2} rotationIntensity={2} floatIntensity={3}>
              <Text3D font="/fonts/Inter_Bold.json" size={1} height={0.2} position={[-2.5, 0, 0]}>
                Creating Account...
                <meshStandardMaterial color="#6366f1" />
              </Text3D>
            </Float>

            <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={2} />
            <Environment preset="sunset" />
            <OrbitControls enableZoom={false} enablePan={false} />
          </Suspense>
        </Canvas>

        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="text-center text-white">
            <div className="w-16 h-16 border-4 border-white border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-xl font-semibold">Setting up your {selectedRole} account...</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="w-full h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 relative overflow-hidden">
      {/* 3D Background */}
      <Canvas camera={{ position: [0, 0, 15], fov: 75 }}>
        <Suspense fallback={null}>
          <Scene3D />
          <OrbitControls
            enableZoom={false}
            enablePan={false}
            autoRotate
            autoRotateSpeed={0.5}
            maxPolarAngle={Math.PI / 2}
            minPolarAngle={Math.PI / 2}
          />
        </Suspense>
      </Canvas>

      {/* UI Overlay */}
      <div className="absolute inset-0 flex items-center justify-center p-4">
        <div className="max-w-6xl w-full">
          {/* Header */}
          <div className="text-center mb-12 animate-fade-in">
            <div className="inline-flex items-center px-6 py-3 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 mb-6">
              <Sparkles className="h-5 w-5 mr-2 text-yellow-400" />
              <span className="text-white font-medium">✨ Welcome to the Future of Careers</span>
            </div>

            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
              Join the{" "}
              <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                Revolution
              </span>
            </h1>

            <p className="text-xl md:text-2xl text-white/80 max-w-3xl mx-auto leading-relaxed">
              Experience career growth like never before with our AI-powered platform.
              <span className="text-yellow-400 font-semibold"> Choose your path below.</span>
            </p>
          </div>

          {/* Signup Cards */}
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* Job Seeker Card */}
            <Card className="bg-white/10 backdrop-blur-md border border-white/20 hover:bg-white/20 transition-all duration-300 transform hover:scale-105 hover:shadow-2xl group">
              <CardContent className="p-8 text-center">
                <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                  <Users className="h-10 w-10 text-white" />
                </div>

                <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30 mb-4">For Job Seekers</Badge>

                <h3 className="text-2xl font-bold text-white mb-4">Find Your Dream Job</h3>

                <p className="text-white/70 mb-6 leading-relaxed">
                  Discover opportunities that match your skills and ambitions. Get personalized recommendations and
                  track your journey.
                </p>

                <div className="space-y-3 mb-8 text-left">
                  <div className="flex items-center text-green-400">
                    <CheckCircle className="h-5 w-5 mr-3" />
                    <span className="text-white/90">AI-powered job matching</span>
                  </div>
                  <div className="flex items-center text-green-400">
                    <CheckCircle className="h-5 w-5 mr-3" />
                    <span className="text-white/90">Real-time application tracking</span>
                  </div>
                  <div className="flex items-center text-green-400">
                    <CheckCircle className="h-5 w-5 mr-3" />
                    <span className="text-white/90">Interview preparation tools</span>
                  </div>
                  <div className="flex items-center text-green-400">
                    <CheckCircle className="h-5 w-5 mr-3" />
                    <span className="text-white/90">Salary insights & analytics</span>
                  </div>
                </div>

                <Button
                  className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-semibold py-3 text-lg transition-all duration-300 transform hover:scale-105"
                  onClick={() => handleSignup("seeker")}
                >
                  <UserPlus className="mr-2 h-5 w-5" />
                  Start as Job Seeker
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </CardContent>
            </Card>

            {/* Company Card */}
            <Card className="bg-white/10 backdrop-blur-md border border-white/20 hover:bg-white/20 transition-all duration-300 transform hover:scale-105 hover:shadow-2xl group">
              <CardContent className="p-8 text-center">
                <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-pink-600 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform">
                  <Building2 className="h-10 w-10 text-white" />
                </div>

                <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30 mb-4">For Companies</Badge>

                <h3 className="text-2xl font-bold text-white mb-4">Hire Top Talent</h3>

                <p className="text-white/70 mb-6 leading-relaxed">
                  Connect with the best candidates and streamline your hiring process with our advanced recruitment
                  tools.
                </p>

                <div className="space-y-3 mb-8 text-left">
                  <div className="flex items-center text-green-400">
                    <CheckCircle className="h-5 w-5 mr-3" />
                    <span className="text-white/90">Smart candidate matching</span>
                  </div>
                  <div className="flex items-center text-green-400">
                    <CheckCircle className="h-5 w-5 mr-3" />
                    <span className="text-white/90">Automated screening process</span>
                  </div>
                  <div className="flex items-center text-green-400">
                    <CheckCircle className="h-5 w-5 mr-3" />
                    <span className="text-white/90">Advanced analytics dashboard</span>
                  </div>
                  <div className="flex items-center text-green-400">
                    <CheckCircle className="h-5 w-5 mr-3" />
                    <span className="text-white/90">Team collaboration tools</span>
                  </div>
                </div>

                <Button
                  variant="outline"
                  className="w-full border-2 border-white/30 text-white hover:bg-white hover:text-purple-600 font-semibold py-3 text-lg transition-all duration-300 transform hover:scale-105"
                  onClick={() => handleSignup("company")}
                >
                  <Building2 className="mr-2 h-5 w-5" />
                  Start Hiring Today
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Trust Indicators */}
          <div className="text-center mt-12 animate-fade-in" style={{ animationDelay: "0.5s" }}>
            <div className="flex items-center justify-center space-x-8 text-white/60 text-sm">
              <div className="flex items-center">
                <Shield className="h-4 w-4 mr-2" />
                <span>Enterprise Security</span>
              </div>
              <div className="flex items-center">
                <Zap className="h-4 w-4 mr-2" />
                <span>Lightning Fast</span>
              </div>
              <div className="flex items-center">
                <Globe className="h-4 w-4 mr-2" />
                <span>Global Network</span>
              </div>
            </div>

            <p className="text-white/50 mt-4">
              Already have an account?{" "}
              <Link href="/login" className="text-blue-400 hover:text-blue-300 font-semibold underline">
                Sign in here
              </Link>
            </p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-8 max-w-2xl mx-auto mt-16 text-center">
            <div className="text-white">
              <div className="text-3xl font-bold bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                50K+
              </div>
              <div className="text-white/60 text-sm">Active Users</div>
            </div>
            <div className="text-white">
              <div className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                10K+
              </div>
              <div className="text-white/60 text-sm">Companies</div>
            </div>
            <div className="text-white">
              <div className="text-3xl font-bold bg-gradient-to-r from-pink-400 to-red-400 bg-clip-text text-transparent">
                95%
              </div>
              <div className="text-white/60 text-sm">Success Rate</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
