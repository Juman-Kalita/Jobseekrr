"use client"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Search, MapPin, Clock, Building2, Filter, Heart, Eye, Share2, Bookmark } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { Header } from "@/components/header"

const JobItem = ({ job, onSave, isSaved, onView, onShare }) => {
  return (
    <Card className="mb-6 bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <CardTitle
              className="text-xl font-bold text-gray-800 mb-2 hover:text-orange-600 cursor-pointer"
              onClick={() => onView(job.id)}
            >
              {job.title}
            </CardTitle>
            <CardDescription className="flex items-center gap-4 text-gray-600">
              <span className="flex items-center gap-1">
                <Building2 className="h-4 w-4" />
                {job.company}
              </span>
              <span className="flex items-center gap-1">
                <MapPin className="h-4 w-4" />
                {job.location}
              </span>
              <span className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                {job.type || "Full-time"}
              </span>
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="secondary" className="bg-green-100 text-green-800">
              ${job.salary || "50k-80k"}
            </Badge>
            {job.urgent && <Badge className="bg-red-500 text-white animate-pulse">URGENT</Badge>}
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <p className="text-gray-600 mb-4 line-clamp-2">
          {job.description ||
            "Join our dynamic team and contribute to exciting projects in a collaborative environment."}
        </p>
        <div className="flex gap-2 mb-4">
          <Badge variant="outline" className="text-xs border-orange-300 text-orange-600">
            React
          </Badge>
          <Badge variant="outline" className="text-xs border-orange-300 text-orange-600">
            TypeScript
          </Badge>
          <Badge variant="outline" className="text-xs border-orange-300 text-orange-600">
            Node.js
          </Badge>
        </div>
        <div className="flex gap-3">
          <Button
            className="flex-1 bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white font-semibold"
            onClick={() => onView(job.id)}
          >
            <Eye className="h-4 w-4 mr-2" />
            View Details
          </Button>
          <Button
            variant="outline"
            onClick={() => onSave(job.id)}
            className={`border-orange-300 hover:bg-orange-50 ${isSaved ? "bg-orange-100 text-orange-700" : "text-orange-600"}`}
          >
            <Heart className={`h-4 w-4 ${isSaved ? "fill-current" : ""}`} />
          </Button>
          <Button
            variant="outline"
            onClick={() => onShare(job)}
            className="border-orange-300 text-orange-600 hover:bg-orange-50"
          >
            <Share2 className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

const JobsPage = () => {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { toast } = useToast()

  const [jobs, setJobs] = useState([])
  const [locationFilter, setLocationFilter] = useState(searchParams.get("location") || "")
  const [jobTypeFilter, setJobTypeFilter] = useState(searchParams.get("jobType") || "")
  const [experienceLevelFilter, setExperienceLevelFilter] = useState(searchParams.get("experienceLevel") || "")
  const [searchTerm, setSearchTerm] = useState(searchParams.get("searchTerm") || "")
  const [sortOrder, setSortOrder] = useState(searchParams.get("sort") || "relevance")
  const [currentPage, setCurrentPage] = useState(Number.parseInt(searchParams.get("page") || "1", 10))
  const [totalPages, setTotalPages] = useState(1)
  const [savedJobs, setSavedJobs] = useState(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("savedJobs")
      return saved ? JSON.parse(saved) : []
    }
    return []
  })

  const pageSize = 10

  // Mock data for demonstration
  const mockJobs = [
    {
      id: 1,
      title: "Senior Frontend Developer",
      company: "TechCorp Inc.",
      location: "New York, NY",
      type: "Full-time",
      salary: "80k-120k",
      urgent: true,
      description:
        "We're looking for a senior frontend developer to join our growing team and work on cutting-edge web applications.",
    },
    {
      id: 2,
      title: "Full Stack Engineer",
      company: "StartupXYZ",
      location: "San Francisco, CA",
      type: "Full-time",
      salary: "90k-140k",
      urgent: false,
      description:
        "Join our innovative startup and help build the next generation of web applications using modern technologies.",
    },
    {
      id: 3,
      title: "React Developer",
      company: "Digital Agency",
      location: "Chicago, IL",
      type: "Contract",
      salary: "60k-90k",
      urgent: false,
      description:
        "Work with a creative team to build beautiful and functional user interfaces for our diverse client base.",
    },
    {
      id: 4,
      title: "UI/UX Developer",
      company: "Design Studio",
      location: "Austin, TX",
      type: "Part-time",
      salary: "40k-60k",
      urgent: false,
      description:
        "Combine your design and development skills to create amazing user experiences for web and mobile applications.",
    },
    {
      id: 5,
      title: "JavaScript Developer",
      company: "Enterprise Solutions",
      location: "Seattle, WA",
      type: "Full-time",
      salary: "70k-100k",
      urgent: false,
      description:
        "Develop and maintain large-scale JavaScript applications for enterprise clients using modern frameworks and tools.",
    },
  ]

  useEffect(() => {
    localStorage.setItem("savedJobs", JSON.stringify(savedJobs))
  }, [savedJobs])

  useEffect(() => {
    // Simulate API call with mock data
    const filteredJobs = mockJobs.filter((job) => {
      const matchesLocation = !locationFilter || locationFilter === "any" || job.location.includes(locationFilter)
      const matchesType = !jobTypeFilter || jobTypeFilter === "any" || job.type === jobTypeFilter
      const matchesSearch =
        !searchTerm ||
        job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        job.company.toLowerCase().includes(searchTerm.toLowerCase())

      return matchesLocation && matchesType && matchesSearch
    })

    // Sort jobs
    const sortedJobs = [...filteredJobs].sort((a, b) => {
      if (sortOrder === "date") return b.id - a.id // Newer first
      if (sortOrder === "salary") return b.salary.localeCompare(a.salary)
      return 0 // relevance (default order)
    })

    setJobs(sortedJobs)
    setTotalPages(Math.ceil(sortedJobs.length / pageSize))
  }, [locationFilter, jobTypeFilter, experienceLevelFilter, searchTerm, sortOrder, currentPage])

  const handleSearch = (e) => {
    e.preventDefault()
    setCurrentPage(1)
    toast({
      title: "Search Updated",
      description: `Found ${jobs.length} jobs matching your criteria`,
    })
  }

  const handleSaveJob = (jobId) => {
    const job = jobs.find((j) => j.id === jobId)
    if (savedJobs.includes(jobId)) {
      setSavedJobs(savedJobs.filter((id) => id !== jobId))
      toast({
        title: "Job Removed",
        description: `${job?.title} removed from saved jobs`,
      })
    } else {
      setSavedJobs([...savedJobs, jobId])
      toast({
        title: "Job Saved",
        description: `${job?.title} added to saved jobs`,
      })
    }
  }

  const handleViewJob = (jobId) => {
    router.push(`/jobs/${jobId}`)
  }

  const handleShareJob = (job) => {
    const jobUrl = `${window.location.origin}/jobs/${job.id}`
    navigator.clipboard.writeText(jobUrl)
    toast({
      title: "Link Copied",
      description: `Share link for ${job.title} copied to clipboard`,
    })
  }

  const handleClearFilters = () => {
    setLocationFilter("")
    setJobTypeFilter("")
    setExperienceLevelFilter("")
    setSearchTerm("")
    setSortOrder("relevance")
    setCurrentPage(1)
    toast({
      title: "Filters Cleared",
      description: "All filters have been reset",
    })
  }

  const handleViewSavedJobs = () => {
    router.push("/saved")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-red-50">
      <Header />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold text-gray-800 mb-2">Find Your Dream Job</h1>
              <p className="text-gray-600">Discover opportunities that match your skills and aspirations</p>
            </div>
            <div className="flex gap-3">
              <Button
                variant="outline"
                className="border-orange-300 text-orange-600 hover:bg-orange-50"
                onClick={handleViewSavedJobs}
              >
                <Bookmark className="h-4 w-4 mr-2" />
                Saved Jobs ({savedJobs.length})
              </Button>
              <Button
                variant="outline"
                className="border-orange-300 text-orange-600 hover:bg-orange-50"
                onClick={handleClearFilters}
              >
                Clear Filters
              </Button>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Filters Sidebar */}
          <div className="lg:col-span-1">
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg sticky top-4">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-gray-800">
                  <Filter className="h-5 w-5" />
                  Filters
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Search */}
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">Search Jobs</label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Job title, company..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 border-orange-200 focus:border-orange-400 focus:ring-orange-400"
                    />
                  </div>
                </div>

                {/* Location Filter */}
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">Location</label>
                  <Select value={locationFilter} onValueChange={setLocationFilter}>
                    <SelectTrigger className="border-orange-200 focus:border-orange-400">
                      <SelectValue placeholder="Any location" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="any">Any location</SelectItem>
                      <SelectItem value="New York">New York</SelectItem>
                      <SelectItem value="San Francisco">San Francisco</SelectItem>
                      <SelectItem value="Chicago">Chicago</SelectItem>
                      <SelectItem value="Austin">Austin</SelectItem>
                      <SelectItem value="Seattle">Seattle</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Job Type Filter */}
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">Job Type</label>
                  <Select value={jobTypeFilter} onValueChange={setJobTypeFilter}>
                    <SelectTrigger className="border-orange-200 focus:border-orange-400">
                      <SelectValue placeholder="Any type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="any">Any type</SelectItem>
                      <SelectItem value="Full-time">Full-time</SelectItem>
                      <SelectItem value="Part-time">Part-time</SelectItem>
                      <SelectItem value="Contract">Contract</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Experience Level Filter */}
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">Experience Level</label>
                  <Select value={experienceLevelFilter} onValueChange={setExperienceLevelFilter}>
                    <SelectTrigger className="border-orange-200 focus:border-orange-400">
                      <SelectValue placeholder="Any level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="any">Any level</SelectItem>
                      <SelectItem value="Entry Level">Entry Level</SelectItem>
                      <SelectItem value="Mid Level">Mid Level</SelectItem>
                      <SelectItem value="Senior Level">Senior Level</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button
                  onClick={handleSearch}
                  className="w-full bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white font-semibold"
                >
                  Apply Filters
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Jobs List */}
          <div className="lg:col-span-3">
            <div className="flex justify-between items-center mb-6">
              <div>
                <p className="text-gray-600">
                  Showing <span className="font-semibold text-orange-600">{jobs.length}</span> jobs
                  {searchTerm && <span> for "{searchTerm}"</span>}
                </p>
              </div>
              <Select value={sortOrder} onValueChange={setSortOrder}>
                <SelectTrigger className="w-48 border-orange-200 focus:border-orange-400">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="relevance">Most Relevant</SelectItem>
                  <SelectItem value="date">Most Recent</SelectItem>
                  <SelectItem value="salary">Highest Salary</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {jobs.length === 0 ? (
              <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
                <CardContent className="text-center py-12">
                  <div className="text-gray-400 mb-4">
                    <Search className="h-16 w-16 mx-auto" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-600 mb-2">No jobs found</h3>
                  <p className="text-gray-500 mb-4">Try adjusting your filters or search terms</p>
                  <Button
                    onClick={handleClearFilters}
                    className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white"
                  >
                    Clear All Filters
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div>
                {jobs.map((job) => (
                  <JobItem
                    key={job.id}
                    job={job}
                    onSave={handleSaveJob}
                    isSaved={savedJobs.includes(job.id)}
                    onView={handleViewJob}
                    onShare={handleShareJob}
                  />
                ))}

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="flex justify-center mt-8">
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        disabled={currentPage === 1}
                        onClick={() => setCurrentPage(currentPage - 1)}
                        className="border-orange-200 hover:bg-orange-50"
                      >
                        Previous
                      </Button>

                      {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                        <Button
                          key={page}
                          variant={page === currentPage ? "default" : "outline"}
                          onClick={() => setCurrentPage(page)}
                          className={
                            page === currentPage
                              ? "bg-gradient-to-r from-orange-500 to-red-500 text-white"
                              : "border-orange-200 hover:bg-orange-50"
                          }
                        >
                          {page}
                        </Button>
                      ))}

                      <Button
                        variant="outline"
                        disabled={currentPage === totalPages}
                        onClick={() => setCurrentPage(currentPage + 1)}
                        className="border-orange-200 hover:bg-orange-50"
                      >
                        Next
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default JobsPage
