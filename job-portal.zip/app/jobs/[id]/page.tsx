"use client"

import type React from "react"
import { useState } from "react"
import Link from "next/link"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { MapPin, Building2, Clock, DollarSign, Users, Briefcase, Heart, Share2, Upload, Globe } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"

export default function JobDetailPage({ params }: { params: { id: string } }) {
  const [isApplying, setIsApplying] = useState(false)
  const [isSaved, setIsSaved] = useState(false)
  const { toast } = useToast()
  const router = useRouter()

  // Mock job data - in real app this would be fetched based on params.id
  const job = {
    id: 1,
    title: "Senior Frontend Developer",
    company: "TechCorp Inc.",
    location: "San Francisco, CA",
    salary: "$120,000 - $150,000",
    type: "Full-time",
    experience: "5+ years",
    posted: "2 days ago",
    applicants: 47,
    description: `We are seeking a talented Senior Frontend Developer to join our dynamic team. You will be responsible for developing and maintaining high-quality web applications using modern technologies.

Key Responsibilities:
• Develop responsive web applications using React, TypeScript, and Next.js
• Collaborate with designers and backend developers to implement user interfaces
• Optimize applications for maximum speed and scalability
• Participate in code reviews and maintain coding standards
• Mentor junior developers and contribute to technical decisions

What We Offer:
• Competitive salary and equity package
• Comprehensive health, dental, and vision insurance
• Flexible work arrangements and remote work options
• Professional development opportunities
• Modern office space in downtown San Francisco`,
    requirements: [
      "5+ years of experience in frontend development",
      "Expert knowledge of React, TypeScript, and modern JavaScript",
      "Experience with Next.js, Tailwind CSS, and state management",
      "Strong understanding of responsive design and cross-browser compatibility",
      "Experience with version control (Git) and CI/CD pipelines",
      "Excellent communication and collaboration skills",
      "Bachelor's degree in Computer Science or equivalent experience",
    ],
    skills: ["React", "TypeScript", "Next.js", "Tailwind CSS", "JavaScript", "HTML/CSS", "Git"],
    benefits: [
      "Health, Dental & Vision Insurance",
      "401(k) with company matching",
      "Flexible PTO policy",
      "Remote work options",
      "Professional development budget",
      "Stock options",
      "Free lunch and snacks",
      "Gym membership reimbursement",
    ],
    company_info: {
      name: "TechCorp Inc.",
      size: "500-1000 employees",
      industry: "Technology",
      founded: "2015",
      website: "https://techcorp.com",
      description:
        "TechCorp is a leading technology company focused on building innovative solutions for businesses worldwide.",
    },
  }

  const handleApply = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsApplying(true)

    // Simulate API call
    setTimeout(() => {
      setIsApplying(false)
      toast({
        title: "Application Submitted!",
        description: "Your application has been sent to the employer. You'll hear back soon!",
      })
    }, 1000)
  }

  const handleSave = () => {
    setIsSaved(!isSaved)
    toast({
      title: isSaved ? "Job Removed" : "Job Saved",
      description: isSaved ? "Job removed from your saved list" : "Job added to your saved list",
    })
  }

  const handleShare = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href)
      toast({
        title: "Link Copied!",
        description: "Job link copied to clipboard",
      })
    } catch (err) {
      toast({
        title: "Error",
        description: "Failed to copy link to clipboard",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-red-50">
      <Header />

      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <nav className="mb-6">
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <Link href="/jobs" className="hover:text-orange-600">
              Jobs
            </Link>
            <span>/</span>
            <span>{job.title}</span>
          </div>
        </nav>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Job Header */}
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-2xl mb-2 text-gray-900">{job.title}</CardTitle>
                    <div className="flex items-center text-gray-600 mb-4">
                      <Building2 className="h-4 w-4 mr-1" />
                      <span className="mr-4">{job.company}</span>
                      <MapPin className="h-4 w-4 mr-1" />
                      <span>{job.location}</span>
                    </div>
                    <div className="flex flex-wrap gap-4 text-sm">
                      <div className="flex items-center">
                        <DollarSign className="h-4 w-4 mr-1 text-green-600" />
                        <span className="font-medium">{job.salary}</span>
                      </div>
                      <div className="flex items-center">
                        <Briefcase className="h-4 w-4 mr-1" />
                        <span>{job.type}</span>
                      </div>
                      <div className="flex items-center">
                        <Users className="h-4 w-4 mr-1" />
                        <span>{job.applicants} applicants</span>
                      </div>
                      <div className="flex items-center">
                        <Clock className="h-4 w-4 mr-1" />
                        <span>Posted {job.posted}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="outline"
                      size="icon"
                      className="border-orange-300 text-orange-600 hover:bg-orange-50"
                      onClick={handleSave}
                    >
                      <Heart className={`h-4 w-4 ${isSaved ? "fill-current text-red-500" : ""}`} />
                    </Button>
                    <Button
                      variant="outline"
                      size="icon"
                      className="border-orange-300 text-orange-600 hover:bg-orange-50"
                      onClick={handleShare}
                    >
                      <Share2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
            </Card>

            {/* Job Description */}
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-gray-900">Job Description</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="prose prose-sm max-w-none">
                  {job.description.split("\n").map((paragraph, index) => (
                    <p key={index} className="mb-4 whitespace-pre-line text-gray-700">
                      {paragraph}
                    </p>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Requirements */}
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-gray-900">Requirements</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {job.requirements.map((requirement, index) => (
                    <li key={index} className="flex items-start">
                      <span className="w-2 h-2 bg-orange-500 rounded-full mt-2 mr-3 flex-shrink-0" />
                      <span className="text-gray-700">{requirement}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            {/* Skills */}
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-gray-900">Required Skills</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {job.skills.map((skill) => (
                    <Badge key={skill} variant="secondary" className="bg-orange-100 text-orange-700">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Benefits */}
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-gray-900">Benefits & Perks</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-3">
                  {job.benefits.map((benefit, index) => (
                    <div key={index} className="flex items-center">
                      <span className="w-2 h-2 bg-green-500 rounded-full mr-3" />
                      <span className="text-sm text-gray-700">{benefit}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            {/* Apply Button */}
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardContent className="p-6">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button
                      className="w-full mb-4 bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white shadow-lg"
                      size="lg"
                    >
                      Apply Now
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                      <DialogTitle>Apply for {job.title}</DialogTitle>
                      <DialogDescription>Fill out the form below to submit your application</DialogDescription>
                    </DialogHeader>
                    <form onSubmit={handleApply} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="cover-letter">Cover Letter</Label>
                        <Textarea
                          id="cover-letter"
                          placeholder="Tell us why you're interested in this position..."
                          rows={4}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="resume">Resume</Label>
                        <div className="border-2 border-dashed border-orange-300 rounded-lg p-6 text-center">
                          <Upload className="h-8 w-8 mx-auto mb-2 text-orange-500" />
                          <p className="text-sm text-gray-600 mb-2">Click to upload or drag and drop</p>
                          <p className="text-xs text-gray-500">PDF, DOC, DOCX (max 5MB)</p>
                          <Input type="file" className="hidden" accept=".pdf,.doc,.docx" />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="portfolio">Portfolio URL (Optional)</Label>
                        <Input id="portfolio" type="url" placeholder="https://yourportfolio.com" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="availability">When can you start?</Label>
                        <Input id="availability" placeholder="e.g., Immediately, 2 weeks notice" />
                      </div>
                      <Button
                        type="submit"
                        className="w-full bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white"
                        disabled={isApplying}
                      >
                        {isApplying ? "Submitting..." : "Submit Application"}
                      </Button>
                    </form>
                  </DialogContent>
                </Dialog>

                <div className="text-center text-sm text-gray-600">
                  <p>Quick apply with your profile</p>
                </div>
              </CardContent>
            </Card>

            {/* Company Info */}
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-gray-900">About {job.company_info.name}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-gray-600">{job.company_info.description}</p>
                <Separator />
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Industry:</span>
                    <span className="text-gray-900">{job.company_info.industry}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Company Size:</span>
                    <span className="text-gray-900">{job.company_info.size}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Founded:</span>
                    <span className="text-gray-900">{job.company_info.founded}</span>
                  </div>
                </div>
                <Button
                  variant="outline"
                  className="w-full border-orange-300 text-orange-600 hover:bg-orange-50"
                  asChild
                >
                  <Link href={job.company_info.website} target="_blank" rel="noopener noreferrer">
                    <Globe className="h-4 w-4 mr-2" />
                    Visit Website
                  </Link>
                </Button>
              </CardContent>
            </Card>

            {/* Similar Jobs */}
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-gray-900">Similar Jobs</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {[
                  { title: "Frontend Developer", company: "StartupABC", salary: "$90k - $120k" },
                  { title: "React Developer", company: "WebCorp", salary: "$100k - $130k" },
                  { title: "UI Developer", company: "DesignTech", salary: "$85k - $110k" },
                ].map((similarJob, index) => (
                  <div
                    key={index}
                    className="border border-orange-200 rounded-lg p-3 hover:bg-orange-50 transition-colors"
                  >
                    <h4 className="font-medium text-sm mb-1 text-gray-900">{similarJob.title}</h4>
                    <p className="text-xs text-gray-600 mb-2">{similarJob.company}</p>
                    <p className="text-xs font-medium text-orange-600">{similarJob.salary}</p>
                  </div>
                ))}
                <Button
                  variant="outline"
                  className="w-full border-orange-300 text-orange-600 hover:bg-orange-50"
                  onClick={() => router.push(`/jobs?company=${job.company_info.name}`)}
                >
                  View More Jobs
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
