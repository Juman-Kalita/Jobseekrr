"use client"

import type React from "react"
import { useState } from "react"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { User, Mail, Phone, MapPin, Upload, Plus, X, FileText, Briefcase, GraduationCap, Award } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export default function ProfilePage() {
  const [isEditing, setIsEditing] = useState(false)
  const [skills, setSkills] = useState(["React", "TypeScript", "Next.js", "Node.js", "Python"])
  const [newSkill, setNewSkill] = useState("")
  const { toast } = useToast()

  const [profile, setProfile] = useState({
    firstName: "John",
    lastName: "Doe",
    email: "john.doe@example.com",
    phone: "+1 (555) 123-4567",
    location: "San Francisco, CA",
    title: "Senior Frontend Developer",
    summary:
      "Experienced frontend developer with 5+ years of experience building modern web applications. Passionate about creating user-friendly interfaces and optimizing performance.",
    experience: [
      {
        id: 1,
        title: "Senior Frontend Developer",
        company: "TechCorp Inc.",
        location: "San Francisco, CA",
        startDate: "2022-01",
        endDate: "Present",
        description: "Lead frontend development for multiple web applications using React and TypeScript.",
      },
      {
        id: 2,
        title: "Frontend Developer",
        company: "WebStudio",
        location: "Remote",
        startDate: "2020-03",
        endDate: "2021-12",
        description: "Developed responsive web applications and collaborated with design teams.",
      },
    ],
    education: [
      {
        id: 1,
        degree: "Bachelor of Science in Computer Science",
        school: "University of California, Berkeley",
        location: "Berkeley, CA",
        startDate: "2016-09",
        endDate: "2020-05",
        gpa: "3.8",
      },
    ],
  })

  const [profilePicture, setProfilePicture] = useState<File | null>(null)
  const [resumeFile, setResumeFile] = useState<File | null>(null)
  const [isAddingExperience, setIsAddingExperience] = useState(false)
  const [isAddingEducation, setIsAddingEducation] = useState(false)

  const [newExperience, setNewExperience] = useState({
    title: "",
    company: "",
    location: "",
    startDate: "",
    endDate: "",
    description: "",
  })

  const [newEducation, setNewEducation] = useState({
    degree: "",
    school: "",
    location: "",
    startDate: "",
    endDate: "",
    gpa: "",
  })

  const handleSave = () => {
    setIsEditing(false)
    toast({
      title: "Profile Updated",
      description: "Your profile has been successfully updated.",
    })
  }

  const addSkill = () => {
    if (newSkill.trim() && !skills.includes(newSkill.trim())) {
      setSkills([...skills, newSkill.trim()])
      setNewSkill("")
    }
  }

  const removeSkill = (skillToRemove: string) => {
    setSkills(skills.filter((skill) => skill !== skillToRemove))
  }

  const handleProfilePictureUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      setProfilePicture(file)
      toast({
        title: "Profile Picture Updated",
        description: "Your profile picture has been successfully updated.",
      })
    }
  }

  const handleResumeUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      setResumeFile(file)
      toast({
        title: "Resume Updated",
        description: "Your resume has been successfully updated.",
      })
    }
  }

  const handleAddExperience = () => {
    setIsAddingExperience(true)
  }

  const handleAddEducation = () => {
    setIsAddingEducation(true)
  }

  const handleSaveExperience = () => {
    setProfile({
      ...profile,
      experience: [...profile.experience, { id: Date.now(), ...newExperience }],
    })
    setNewExperience({ title: "", company: "", location: "", startDate: "", endDate: "", description: "" })
    setIsAddingExperience(false)
  }

  const handleSaveEducation = () => {
    setProfile({
      ...profile,
      education: [...profile.education, { id: Date.now(), ...newEducation }],
    })
    setNewEducation({ degree: "", school: "", location: "", startDate: "", endDate: "", gpa: "" })
    setIsAddingEducation(false)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-red-50">
      <Header />

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <h1 className="text-3xl font-bold text-gray-900">My Profile</h1>
            <Button
              className={
                isEditing
                  ? "bg-gradient-to-r from-green-500 to-teal-500 hover:from-green-600 hover:to-teal-600 text-white shadow-lg"
                  : "bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white shadow-lg"
              }
              onClick={() => (isEditing ? handleSave() : setIsEditing(true))}
            >
              {isEditing ? "Save Changes" : "Edit Profile"}
            </Button>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Left Column */}
            <div className="lg:col-span-1 space-y-6">
              {/* Profile Picture & Basic Info */}
              <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                <CardContent className="p-6 text-center">
                  <Avatar className="w-24 h-24 mx-auto mb-4">
                    <AvatarImage
                      src={profilePicture ? URL.createObjectURL(profilePicture) : "/placeholder.svg?height=96&width=96"}
                    />
                    <AvatarFallback className="text-2xl bg-gradient-to-br from-orange-500 to-red-500 text-white">
                      {profile.firstName.charAt(0)}
                      {profile.lastName.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  {isEditing && (
                    <>
                      <Input
                        type="file"
                        id="profile-picture-upload"
                        accept="image/*"
                        className="hidden"
                        onChange={handleProfilePictureUpload}
                      />
                      <Label htmlFor="profile-picture-upload">
                        <Button
                          variant="outline"
                          size="sm"
                          className="mb-4 border-orange-300 text-orange-600 hover:bg-orange-50"
                        >
                          <Upload className="h-4 w-4 mr-2" />
                          Upload Photo
                        </Button>
                      </Label>
                    </>
                  )}
                  <h2 className="text-xl font-semibold mb-1 text-gray-900">
                    {profile.firstName} {profile.lastName}
                  </h2>
                  <p className="text-orange-600 font-semibold mb-4">{profile.title}</p>

                  <div className="space-y-2 text-sm">
                    <div className="flex items-center justify-center">
                      <Mail className="h-4 w-4 mr-2" />
                      <span>{profile.email}</span>
                    </div>
                    <div className="flex items-center justify-center">
                      <Phone className="h-4 w-4 mr-2" />
                      <span>{profile.phone}</span>
                    </div>
                    <div className="flex items-center justify-center">
                      <MapPin className="h-4 w-4 mr-2" />
                      <span>{profile.location}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Skills */}
              <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center text-gray-900">
                    <Award className="h-5 w-5 mr-2 text-orange-500" />
                    Skills
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {skills.map((skill) => (
                      <Badge key={skill} variant="secondary" className="relative group bg-orange-100 text-orange-700">
                        {skill}
                        {isEditing && (
                          <button
                            onClick={() => removeSkill(skill)}
                            className="ml-2 opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <X className="h-3 w-3" />
                          </button>
                        )}
                      </Badge>
                    ))}
                  </div>
                  {isEditing && (
                    <div className="flex gap-2">
                      <Input
                        placeholder="Add a skill"
                        value={newSkill}
                        onChange={(e) => setNewSkill(e.target.value)}
                        onKeyPress={(e) => e.key === "Enter" && addSkill()}
                        className="border-orange-300 focus:border-orange-500 focus:ring-orange-500"
                      />
                      <Button
                        size="sm"
                        className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white"
                        onClick={addSkill}
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Resume */}
              <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center text-gray-900">
                    <FileText className="h-5 w-5 mr-2 text-orange-500" />
                    Resume
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="border-2 border-dashed border-orange-300 rounded-lg p-6 text-center">
                    <FileText className="h-8 w-8 mx-auto mb-2 text-orange-500" />
                    <p className="text-sm text-gray-600 mb-2">
                      Current Resume: {resumeFile ? resumeFile.name : "resume.pdf"}
                    </p>
                    {isEditing && (
                      <>
                        <Input
                          type="file"
                          id="resume-upload"
                          accept=".pdf,.doc,.docx"
                          className="hidden"
                          onChange={handleResumeUpload}
                        />
                        <Label htmlFor="resume-upload">
                          <Button
                            variant="outline"
                            size="sm"
                            className="border-orange-300 text-orange-600 hover:bg-orange-50"
                          >
                            <Upload className="h-4 w-4 mr-2" />
                            Update Resume
                          </Button>
                        </Label>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Right Column */}
            <div className="lg:col-span-2 space-y-6">
              {/* Personal Information */}
              <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center text-gray-900">
                    <User className="h-5 w-5 mr-2 text-orange-500" />
                    Personal Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="firstName">First Name</Label>
                      <Input
                        id="firstName"
                        value={profile.firstName}
                        onChange={(e) => setProfile({ ...profile, firstName: e.target.value })}
                        disabled={!isEditing}
                        className="border-orange-300 focus:border-orange-500 focus:ring-orange-500"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input
                        id="lastName"
                        value={profile.lastName}
                        onChange={(e) => setProfile({ ...profile, lastName: e.target.value })}
                        disabled={!isEditing}
                        className="border-orange-300 focus:border-orange-500 focus:ring-orange-500"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={profile.email}
                      onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                      disabled={!isEditing}
                      className="border-orange-300 focus:border-orange-500 focus:ring-orange-500"
                    />
                  </div>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone</Label>
                      <Input
                        id="phone"
                        value={profile.phone}
                        onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                        disabled={!isEditing}
                        className="border-orange-300 focus:border-orange-500 focus:ring-orange-500"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="location">Location</Label>
                      <Input
                        id="location"
                        value={profile.location}
                        onChange={(e) => setProfile({ ...profile, location: e.target.value })}
                        disabled={!isEditing}
                        className="border-orange-300 focus:border-orange-500 focus:ring-orange-500"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="title">Professional Title</Label>
                    <Input
                      id="title"
                      value={profile.title}
                      onChange={(e) => setProfile({ ...profile, title: e.target.value })}
                      disabled={!isEditing}
                      className="border-orange-300 focus:border-orange-500 focus:ring-orange-500"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="summary">Professional Summary</Label>
                    <Textarea
                      id="summary"
                      rows={4}
                      value={profile.summary}
                      onChange={(e) => setProfile({ ...profile, summary: e.target.value })}
                      disabled={!isEditing}
                      className="border-orange-300 focus:border-orange-500 focus:ring-orange-500"
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Work Experience */}
              <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center text-gray-900">
                      <Briefcase className="h-5 w-5 mr-2 text-orange-500" />
                      Work Experience
                    </CardTitle>
                    {isEditing && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-orange-300 text-orange-600 hover:bg-orange-50"
                        onClick={handleAddExperience}
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        Add Experience
                      </Button>
                    )}
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  {isAddingExperience && (
                    <div className="space-y-4 p-4 bg-orange-50 rounded-lg">
                      <Input
                        placeholder="Title"
                        value={newExperience.title}
                        onChange={(e) => setNewExperience({ ...newExperience, title: e.target.value })}
                        className="border-orange-300 focus:border-orange-500 focus:ring-orange-500"
                      />
                      <Input
                        placeholder="Company"
                        value={newExperience.company}
                        onChange={(e) => setNewExperience({ ...newExperience, company: e.target.value })}
                        className="border-orange-300 focus:border-orange-500 focus:ring-orange-500"
                      />
                      <Input
                        placeholder="Location"
                        value={newExperience.location}
                        onChange={(e) => setNewExperience({ ...newExperience, location: e.target.value })}
                        className="border-orange-300 focus:border-orange-500 focus:ring-orange-500"
                      />
                      <Input
                        placeholder="Start Date"
                        value={newExperience.startDate}
                        onChange={(e) => setNewExperience({ ...newExperience, startDate: e.target.value })}
                        className="border-orange-300 focus:border-orange-500 focus:ring-orange-500"
                      />
                      <Input
                        placeholder="End Date"
                        value={newExperience.endDate}
                        onChange={(e) => setNewExperience({ ...newExperience, endDate: e.target.value })}
                        className="border-orange-300 focus:border-orange-500 focus:ring-orange-500"
                      />
                      <Textarea
                        placeholder="Description"
                        value={newExperience.description}
                        onChange={(e) => setNewExperience({ ...newExperience, description: e.target.value })}
                        className="border-orange-300 focus:border-orange-500 focus:ring-orange-500"
                      />
                      <Button
                        className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white"
                        onClick={handleSaveExperience}
                      >
                        Save Experience
                      </Button>
                    </div>
                  )}
                  {profile.experience.map((exp, index) => (
                    <div key={exp.id}>
                      {index > 0 && <Separator />}
                      <div className="space-y-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h4 className="font-semibold text-gray-900">{exp.title}</h4>
                            <p className="text-gray-600">
                              {exp.company} • {exp.location}
                            </p>
                            <p className="text-sm text-gray-600">
                              {exp.startDate} - {exp.endDate}
                            </p>
                          </div>
                          {isEditing && (
                            <Button variant="ghost" size="sm" className="text-orange-600 hover:bg-orange-50">
                              Edit
                            </Button>
                          )}
                        </div>
                        <p className="text-sm text-gray-700">{exp.description}</p>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Education */}
              <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center text-gray-900">
                      <GraduationCap className="h-5 w-5 mr-2 text-orange-500" />
                      Education
                    </CardTitle>
                    {isEditing && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-orange-300 text-orange-600 hover:bg-orange-50"
                        onClick={handleAddEducation}
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        Add Education
                      </Button>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  {isAddingEducation && (
                    <div className="space-y-4 p-4 bg-orange-50 rounded-lg mb-6">
                      <Input
                        placeholder="Degree"
                        value={newEducation.degree}
                        onChange={(e) => setNewEducation({ ...newEducation, degree: e.target.value })}
                        className="border-orange-300 focus:border-orange-500 focus:ring-orange-500"
                      />
                      <Input
                        placeholder="School"
                        value={newEducation.school}
                        onChange={(e) => setNewEducation({ ...newEducation, school: e.target.value })}
                        className="border-orange-300 focus:border-orange-500 focus:ring-orange-500"
                      />
                      <Input
                        placeholder="Location"
                        value={newEducation.location}
                        onChange={(e) => setNewEducation({ ...newEducation, location: e.target.value })}
                        className="border-orange-300 focus:border-orange-500 focus:ring-orange-500"
                      />
                      <Input
                        placeholder="Start Date"
                        value={newEducation.startDate}
                        onChange={(e) => setNewEducation({ ...newEducation, startDate: e.target.value })}
                        className="border-orange-300 focus:border-orange-500 focus:ring-orange-500"
                      />
                      <Input
                        placeholder="End Date"
                        value={newEducation.endDate}
                        onChange={(e) => setNewEducation({ ...newEducation, endDate: e.target.value })}
                        className="border-orange-300 focus:border-orange-500 focus:ring-orange-500"
                      />
                      <Input
                        placeholder="GPA"
                        value={newEducation.gpa}
                        onChange={(e) => setNewEducation({ ...newEducation, gpa: e.target.value })}
                        className="border-orange-300 focus:border-orange-500 focus:ring-orange-500"
                      />
                      <Button
                        className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white"
                        onClick={handleSaveEducation}
                      >
                        Save Education
                      </Button>
                    </div>
                  )}
                  {profile.education.map((edu) => (
                    <div key={edu.id} className="space-y-2">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-semibold text-gray-900">{edu.degree}</h4>
                          <p className="text-gray-600">
                            {edu.school} • {edu.location}
                          </p>
                          <p className="text-sm text-gray-600">
                            {edu.startDate} - {edu.endDate} • GPA: {edu.gpa}
                          </p>
                        </div>
                        {isEditing && (
                          <Button variant="ghost" size="sm" className="text-orange-600 hover:bg-orange-50">
                            Edit
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
