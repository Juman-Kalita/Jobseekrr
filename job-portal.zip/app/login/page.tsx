"use client"

import type React from "react"
import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Briefcase, Eye, EyeOff, ArrowRight, Sparkles, Shield, Users } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"
import { authenticateUser } from "@/lib/auth"

export default function LoginPage() {
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()
  const router = useRouter()
  const [seekerEmail, setSeekerEmail] = useState("")
  const [seekerPassword, setSeekerPassword] = useState("")
  const [companyEmail, setCompanyEmail] = useState("")
  const [companyPassword, setCompanyPassword] = useState("")

  const handleLogin = async (e: React.FormEvent, userType: "seeker" | "company") => {
    e.preventDefault()
    setIsLoading(true)

    const email = userType === "seeker" ? seekerEmail : companyEmail
    const password = userType === "seeker" ? seekerPassword : companyPassword

    if (!email || !password) {
      toast({
        title: "Error",
        description: "Please fill in all fields.",
        variant: "destructive",
      })
      setIsLoading(false)
      return
    }

    try {
      const result = await authenticateUser(email, password, userType)

      if (result?.success) {
        toast({
          title: "Welcome Back! 🎉",
          description: `Successfully signed in. Redirecting to your dashboard...`,
        })

        setTimeout(() => {
          if (userType === "seeker") {
            router.push("/dashboard/seeker")
          } else {
            router.push("/dashboard/company")
          }
        }, 1000)
      } else {
        toast({
          title: "Login Failed",
          description: result?.error || "Invalid credentials. Please try again.",
          variant: "destructive",
        })
      }
    } catch (error: any) {
      console.error("Login error:", error)
      toast({
        title: "Login Error",
        description: error?.message || "An error occurred during login.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const benefits = [
    { icon: Sparkles, text: "AI-powered job matching", color: "text-orange-500" },
    { icon: Users, text: "Connect with top companies", color: "text-red-500" },
    { icon: Shield, text: "Secure & trusted platform", color: "text-yellow-500" },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-red-50">
      {/* Background Pattern */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-orange-400/20 rounded-full blur-3xl animate-pulse"></div>
        <div
          className="absolute -bottom-40 -left-40 w-80 h-80 bg-red-400/20 rounded-full blur-3xl animate-pulse"
          style={{ animationDelay: "2s" }}
        ></div>
        <div
          className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-yellow-400/10 rounded-full blur-3xl animate-pulse"
          style={{ animationDelay: "4s" }}
        ></div>
      </div>

      <div className="relative z-10 container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center space-x-3 mb-8 group">
            <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-red-500 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
              <Briefcase className="h-6 w-6 text-white" />
            </div>
            <span className="text-2xl font-bold bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">
              CareerBoost
            </span>
          </Link>
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-gray-900">Welcome Back!</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Sign in to continue your career journey and discover amazing opportunities.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Left Side - Hero Content */}
          <div className="space-y-8">
            {/* Hero Image */}
            <div className="relative rounded-3xl overflow-hidden shadow-2xl">
              <Image
                src="https://images.unsplash.com/photo-1521737711867-e3b97375f902?w=600&h=400&fit=crop"
                alt="Professional success"
                width={600}
                height={400}
                className="w-full h-80 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
              <div className="absolute bottom-6 left-6 text-white">
                <h3 className="text-2xl font-bold mb-2">Continue Your Success Story</h3>
                <p className="text-white/90">Join thousands of professionals who found their dream careers</p>
              </div>
            </div>

            {/* Benefits */}
            <Card className="border-0 shadow-xl bg-white/80 backdrop-blur-sm">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold mb-6 text-gray-900">Why Professionals Choose Us</h3>
                <div className="space-y-6">
                  {benefits.map((benefit, index) => (
                    <div key={index} className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-orange-100 to-red-100 rounded-xl flex items-center justify-center">
                        <benefit.icon className={`h-6 w-6 ${benefit.color}`} />
                      </div>
                      <span className="font-semibold text-gray-700 text-lg">{benefit.text}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Success Stats */}
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center p-4 bg-white/80 backdrop-blur-sm rounded-2xl shadow-lg">
                <div className="text-2xl font-bold text-orange-600">500K+</div>
                <div className="text-sm text-gray-600">Success Stories</div>
              </div>
              <div className="text-center p-4 bg-white/80 backdrop-blur-sm rounded-2xl shadow-lg">
                <div className="text-2xl font-bold text-red-600">165%</div>
                <div className="text-sm text-gray-600">Avg Salary Increase</div>
              </div>
              <div className="text-center p-4 bg-white/80 backdrop-blur-sm rounded-2xl shadow-lg">
                <div className="text-2xl font-bold text-yellow-600">15K+</div>
                <div className="text-sm text-gray-600">Top Companies</div>
              </div>
            </div>
          </div>

          {/* Right Side - Login Form */}
          <div className="flex items-center justify-center">
            <Card className="w-full max-w-md border-0 shadow-2xl bg-white/90 backdrop-blur-sm">
              <CardHeader className="text-center pb-2">
                <CardTitle className="text-2xl font-bold text-gray-900">Sign In to Your Account</CardTitle>
                <CardDescription className="text-lg text-gray-600">
                  Choose your account type to continue
                </CardDescription>
              </CardHeader>

              <CardContent className="p-8">
                <Tabs defaultValue="seeker" className="w-full">
                  <TabsList className="grid w-full grid-cols-2 mb-8 bg-gray-100">
                    <TabsTrigger
                      value="seeker"
                      className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white font-semibold"
                    >
                      Job Seeker
                    </TabsTrigger>
                    <TabsTrigger
                      value="company"
                      className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white font-semibold"
                    >
                      Company
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="seeker">
                    <form onSubmit={(e) => handleLogin(e, "seeker")} className="space-y-6">
                      <div className="space-y-2">
                        <Label htmlFor="seeker-email" className="text-gray-700 font-medium">
                          Email Address
                        </Label>
                        <Input
                          id="seeker-email"
                          type="email"
                          placeholder="john@example.com"
                          required
                          value={seekerEmail}
                          onChange={(e) => setSeekerEmail(e.target.value)}
                          className="h-12 border-gray-200 focus:border-orange-500 focus:ring-orange-500"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="seeker-password" className="text-gray-700 font-medium">
                          Password
                        </Label>
                        <div className="relative">
                          <Input
                            id="seeker-password"
                            type={showPassword ? "text" : "password"}
                            placeholder="Enter your password"
                            required
                            value={seekerPassword}
                            onChange={(e) => setSeekerPassword(e.target.value)}
                            className="h-12 pr-12 border-gray-200 focus:border-orange-500 focus:ring-orange-500"
                          />
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                            onClick={() => setShowPassword(!showPassword)}
                          >
                            {showPassword ? (
                              <EyeOff className="h-4 w-4 text-gray-500" />
                            ) : (
                              <Eye className="h-4 w-4 text-gray-500" />
                            )}
                          </Button>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <Link
                          href="/forgot-password"
                          className="text-sm text-orange-600 hover:text-orange-700 font-medium"
                        >
                          Forgot password?
                        </Link>
                      </div>
                      <Button
                        type="submit"
                        className="w-full h-12 bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white font-semibold shadow-lg"
                        disabled={isLoading}
                      >
                        {isLoading ? (
                          <div className="flex items-center">
                            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                            Signing in...
                          </div>
                        ) : (
                          <>
                            Sign In
                            <ArrowRight className="ml-2 h-4 w-4" />
                          </>
                        )}
                      </Button>
                    </form>
                  </TabsContent>

                  <TabsContent value="company">
                    <form onSubmit={(e) => handleLogin(e, "company")} className="space-y-6">
                      <div className="space-y-2">
                        <Label htmlFor="company-email" className="text-gray-700 font-medium">
                          Company Email
                        </Label>
                        <Input
                          id="company-email"
                          type="email"
                          placeholder="hr@company.com"
                          required
                          value={companyEmail}
                          onChange={(e) => setCompanyEmail(e.target.value)}
                          className="h-12 border-gray-200 focus:border-orange-500 focus:ring-orange-500"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="company-password" className="text-gray-700 font-medium">
                          Password
                        </Label>
                        <div className="relative">
                          <Input
                            id="company-password"
                            type={showPassword ? "text" : "password"}
                            placeholder="Enter your password"
                            required
                            value={companyPassword}
                            onChange={(e) => setCompanyPassword(e.target.value)}
                            className="h-12 pr-12 border-gray-200 focus:border-orange-500 focus:ring-orange-500"
                          />
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                            onClick={() => setShowPassword(!showPassword)}
                          >
                            {showPassword ? (
                              <EyeOff className="h-4 w-4 text-gray-500" />
                            ) : (
                              <Eye className="h-4 w-4 text-gray-500" />
                            )}
                          </Button>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <Link
                          href="/forgot-password"
                          className="text-sm text-orange-600 hover:text-orange-700 font-medium"
                        >
                          Forgot password?
                        </Link>
                      </div>
                      <Button
                        type="submit"
                        className="w-full h-12 bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white font-semibold shadow-lg"
                        disabled={isLoading}
                      >
                        {isLoading ? (
                          <div className="flex items-center">
                            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                            Signing in...
                          </div>
                        ) : (
                          <>
                            Sign In
                            <ArrowRight className="ml-2 h-4 w-4" />
                          </>
                        )}
                      </Button>
                    </form>
                  </TabsContent>
                </Tabs>

                <div className="mt-8 text-center">
                  <p className="text-sm text-gray-600">
                    Don't have an account?{" "}
                    <Link href="/register" className="text-orange-600 hover:text-orange-700 font-semibold">
                      Create one here
                    </Link>
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
