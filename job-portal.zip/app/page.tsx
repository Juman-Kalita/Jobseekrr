"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Briefcase,
  Search,
  Users,
  Building2,
  TrendingUp,
  Star,
  ArrowRight,
  Zap,
  Shield,
  Globe,
  Play,
  ChevronRight,
} from "lucide-react"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"

export default function HomePage() {
  const [email, setEmail] = useState("")
  const [searchQuery, setSearchQuery] = useState("")
  const router = useRouter()
  const { toast } = useToast()

  const handleEmailSignup = (e: React.FormEvent) => {
    e.preventDefault()
    if (email) {
      toast({
        title: "Welcome aboard! 🎉",
        description: "Check your email for next steps.",
      })
      setEmail("")
    }
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      router.push(`/jobs?searchTerm=${encodeURIComponent(searchQuery)}`)
    }
  }

  const handleGetStarted = (userType: "seeker" | "company") => {
    router.push(`/register?type=${userType}`)
  }

  const handleWatchDemo = () => {
    toast({
      title: "Demo Video",
      description: "Demo video will be available soon!",
    })
  }

  const handleLearnMore = (section: string) => {
    toast({
      title: "Learn More",
      description: `More information about ${section} coming soon!`,
    })
  }

  const stats = [
    { label: "Active Jobs", value: "50,000+", icon: Briefcase },
    { label: "Companies", value: "15,000+", icon: Building2 },
    { label: "Success Stories", value: "500,000+", icon: Users },
    { label: "Average Salary Increase", value: "165%", icon: TrendingUp },
  ]

  const features = [
    {
      icon: Zap,
      title: "AI-Powered Matching",
      description: "Our advanced AI finds the perfect job matches based on your skills and preferences.",
      action: () => handleLearnMore("AI matching"),
    },
    {
      icon: Shield,
      title: "Secure & Trusted",
      description: "Your data is protected with enterprise-grade security and privacy measures.",
      action: () => handleLearnMore("security"),
    },
    {
      icon: Globe,
      title: "Global Opportunities",
      description: "Access job opportunities from companies worldwide, including remote positions.",
      action: () => handleLearnMore("global opportunities"),
    },
  ]

  const testimonials = [
    {
      name: "Sarah Johnson",
      role: "Software Engineer at Google",
      image: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=60&h=60&fit=crop&crop=face",
      content:
        "CareerBoost helped me land my dream job at Google in just 2 weeks. The AI matching is incredibly accurate!",
      rating: 5,
    },
    {
      name: "Michael Chen",
      role: "Product Manager at Microsoft",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=60&h=60&fit=crop&crop=face",
      content: "The platform made my job search so much easier. I got multiple offers and found the perfect role.",
      rating: 5,
    },
    {
      name: "Emily Davis",
      role: "UX Designer at Apple",
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=60&h=60&fit=crop&crop=face",
      content: "Amazing experience! The personalized recommendations were spot-on and saved me so much time.",
      rating: 5,
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-red-50">
      {/* Header */}
      <header className="bg-white/90 backdrop-blur-sm shadow-lg border-b border-orange-100 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2 text-2xl font-bold text-gray-800">
            <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-red-500 rounded-lg flex items-center justify-center">
              <Briefcase className="h-5 w-5 text-white" />
            </div>
            <span>CareerBoost</span>
          </Link>

          <nav className="hidden md:flex space-x-8">
            <Link href="/jobs" className="text-gray-600 hover:text-orange-600 font-medium transition-colors">
              Jobs
            </Link>
            <Link href="/companies" className="text-gray-600 hover:text-orange-600 font-medium transition-colors">
              Companies
            </Link>
            <Link href="/salary-guide" className="text-gray-600 hover:text-orange-600 font-medium transition-colors">
              Salary Guide
            </Link>
            <Link href="/resources" className="text-gray-600 hover:text-orange-600 font-medium transition-colors">
              Resources
            </Link>
          </nav>

          <div className="flex items-center space-x-4">
            <Button
              variant="outline"
              className="border-orange-300 text-orange-600 hover:bg-orange-50"
              onClick={() => router.push("/login")}
            >
              Sign In
            </Button>
            <Button
              className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white shadow-lg"
              onClick={() => router.push("/register")}
            >
              Get Started
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <div className="max-w-4xl mx-auto">
            <Badge className="mb-6 bg-gradient-to-r from-orange-500 to-red-500 text-white px-4 py-2">
              ✨ #1 Job Platform of 2024
            </Badge>

            <h1 className="text-5xl md:text-7xl font-bold text-gray-900 mb-6 leading-tight">
              Find Your{" "}
              <span className="bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">
                Dream Career
              </span>
            </h1>

            <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
              Connect with top companies, discover amazing opportunities, and accelerate your career growth with our
              AI-powered job matching platform.
            </p>

            {/* Search Bar */}
            <form onSubmit={handleSearch} className="max-w-2xl mx-auto mb-8">
              <div className="flex flex-col md:flex-row gap-4 p-2 bg-white rounded-2xl shadow-xl border border-orange-100">
                <div className="flex-1 relative">
                  <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <Input
                    placeholder="Job title, company, or keywords..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-12 border-0 text-lg h-14 focus:ring-0"
                  />
                </div>
                <Button
                  type="submit"
                  size="lg"
                  className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white px-8 h-14"
                >
                  Search Jobs
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </div>
            </form>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Button
                size="lg"
                className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white px-8 py-4 text-lg shadow-lg"
                onClick={() => handleGetStarted("seeker")}
              >
                <Users className="mr-2 h-5 w-5" />
                I'm Looking for a Job
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-orange-300 text-orange-600 hover:bg-orange-50 px-8 py-4 text-lg"
                onClick={() => handleGetStarted("company")}
              >
                <Building2 className="mr-2 h-5 w-5" />
                I'm Hiring Talent
              </Button>
            </div>

            {/* Demo Button */}
            <Button variant="ghost" className="text-orange-600 hover:bg-orange-50" onClick={handleWatchDemo}>
              <Play className="mr-2 h-4 w-4" />
              Watch Demo
            </Button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 px-4 bg-white/50">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <Card
                key={index}
                className="text-center border-0 shadow-lg bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300"
              >
                <CardContent className="p-6">
                  <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-red-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <stat.icon className="h-8 w-8 text-white" />
                  </div>
                  <div className="text-3xl font-bold text-gray-900 mb-2">{stat.value}</div>
                  <div className="text-gray-600">{stat.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Why Choose CareerBoost?</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We're revolutionizing the way people find jobs and companies find talent with cutting-edge technology and
              personalized experiences.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card
                key={index}
                className="border-0 shadow-lg bg-white/80 backdrop-blur-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-2"
              >
                <CardHeader>
                  <div className="w-16 h-16 bg-gradient-to-br from-orange-500 to-red-500 rounded-2xl flex items-center justify-center mb-4">
                    <feature.icon className="h-8 w-8 text-white" />
                  </div>
                  <CardTitle className="text-xl font-bold text-gray-900">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-gray-600 mb-4 text-base leading-relaxed">
                    {feature.description}
                  </CardDescription>
                  <Button variant="ghost" className="text-orange-600 hover:bg-orange-50 p-0" onClick={feature.action}>
                    Learn more
                    <ChevronRight className="ml-1 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 px-4 bg-white/50">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Success Stories</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Join thousands of professionals who've transformed their careers with CareerBoost
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <Image
                      src={testimonial.image || "/placeholder.svg"}
                      alt={testimonial.name}
                      width={50}
                      height={50}
                      className="rounded-full mr-4"
                    />
                    <div>
                      <h4 className="font-semibold text-gray-900">{testimonial.name}</h4>
                      <p className="text-sm text-gray-600">{testimonial.role}</p>
                    </div>
                  </div>
                  <div className="flex mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-current text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-700 italic">"{testimonial.content}"</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <Card className="border-0 shadow-2xl bg-gradient-to-r from-orange-500 to-red-500 text-white overflow-hidden relative">
            <div className="absolute inset-0 bg-black/10"></div>
            <CardContent className="relative p-12 text-center">
              <h2 className="text-4xl md:text-5xl font-bold mb-6">Ready to Transform Your Career?</h2>
              <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
                Join over 500,000 professionals who've found their dream jobs through CareerBoost. Your next opportunity
                is just one click away.
              </p>

              <form onSubmit={handleEmailSignup} className="max-w-md mx-auto mb-6">
                <div className="flex gap-4">
                  <Input
                    type="email"
                    placeholder="Enter your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="bg-white/20 border-white/30 text-white placeholder:text-white/70 focus:bg-white/30"
                    required
                  />
                  <Button
                    type="submit"
                    variant="secondary"
                    className="bg-white text-orange-600 hover:bg-gray-100 font-semibold px-6"
                  >
                    Get Started
                  </Button>
                </div>
              </form>

              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  size="lg"
                  variant="secondary"
                  className="bg-white text-orange-600 hover:bg-gray-100 font-semibold px-8"
                  onClick={() => handleGetStarted("seeker")}
                >
                  Find Jobs
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white text-white hover:bg-white/20 font-semibold px-8"
                  onClick={() => handleGetStarted("company")}
                >
                  Post Jobs
                  <Building2 className="ml-2 h-5 w-5" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16 px-4">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-red-500 rounded-lg flex items-center justify-center">
                  <Briefcase className="h-5 w-5 text-white" />
                </div>
                <span className="text-xl font-bold">CareerBoost</span>
              </div>
              <p className="text-gray-400 mb-4">Connecting talent with opportunity through AI-powered job matching.</p>
            </div>

            <div>
              <h4 className="font-semibold mb-4">For Job Seekers</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/jobs" className="hover:text-orange-400 transition-colors">
                    Browse Jobs
                  </Link>
                </li>
                <li>
                  <Link href="/companies" className="hover:text-orange-400 transition-colors">
                    Companies
                  </Link>
                </li>
                <li>
                  <Link href="/salary-guide" className="hover:text-orange-400 transition-colors">
                    Salary Guide
                  </Link>
                </li>
                <li>
                  <Link href="/resources" className="hover:text-orange-400 transition-colors">
                    Career Resources
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">For Employers</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/company/post-job" className="hover:text-orange-400 transition-colors">
                    Post a Job
                  </Link>
                </li>
                <li>
                  <Link href="/company/dashboard" className="hover:text-orange-400 transition-colors">
                    Employer Dashboard
                  </Link>
                </li>
                <li>
                  <Button
                    variant="ghost"
                    className="p-0 h-auto text-gray-400 hover:text-orange-400"
                    onClick={() => handleLearnMore("pricing")}
                  >
                    Pricing
                  </Button>
                </li>
                <li>
                  <Button
                    variant="ghost"
                    className="p-0 h-auto text-gray-400 hover:text-orange-400"
                    onClick={() => handleLearnMore("enterprise")}
                  >
                    Enterprise
                  </Button>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Button
                    variant="ghost"
                    className="p-0 h-auto text-gray-400 hover:text-orange-400"
                    onClick={() => handleLearnMore("about")}
                  >
                    About Us
                  </Button>
                </li>
                <li>
                  <Button
                    variant="ghost"
                    className="p-0 h-auto text-gray-400 hover:text-orange-400"
                    onClick={() => handleLearnMore("contact")}
                  >
                    Contact
                  </Button>
                </li>
                <li>
                  <Button
                    variant="ghost"
                    className="p-0 h-auto text-gray-400 hover:text-orange-400"
                    onClick={() => handleLearnMore("privacy")}
                  >
                    Privacy Policy
                  </Button>
                </li>
                <li>
                  <Button
                    variant="ghost"
                    className="p-0 h-auto text-gray-400 hover:text-orange-400"
                    onClick={() => handleLearnMore("terms")}
                  >
                    Terms of Service
                  </Button>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8 text-center text-gray-400">
            <p>&copy; 2024 CareerBoost. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
