"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, MapPin, Building2, Calendar, Eye, MessageSquare, FileText, Plus } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"

export default function AppliedJobsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const { toast } = useToast()
  const router = useRouter()

  const applications = [
    {
      id: 1,
      jobTitle: "Senior Frontend Developer",
      company: "TechCorp Inc.",
      location: "San Francisco, CA",
      appliedDate: "2024-01-15",
      status: "Under Review",
      statusColor: "bg-yellow-500",
      salary: "$120k - $150k",
      jobType: "Full-time",
      notes: "Completed technical assessment",
      nextStep: "Waiting for technical interview",
      interviewDate: null,
    },
    {
      id: 2,
      jobTitle: "Product Manager",
      company: "StartupXYZ",
      location: "Remote",
      appliedDate: "2024-01-10",
      status: "Interview Scheduled",
      statusColor: "bg-green-500",
      salary: "$100k - $130k",
      jobType: "Full-time",
      notes: "Phone screening completed successfully",
      nextStep: "Final round interview",
      interviewDate: "2024-01-25",
    },
    {
      id: 3,
      jobTitle: "UX Designer",
      company: "Design Studio",
      location: "New York, NY",
      appliedDate: "2024-01-05",
      status: "Rejected",
      statusColor: "bg-red-500",
      salary: "$80k - $100k",
      jobType: "Full-time",
      notes: "Portfolio didn't match requirements",
      nextStep: null,
      interviewDate: null,
    },
    {
      id: 4,
      jobTitle: "Backend Engineer",
      company: "CloudTech",
      location: "Austin, TX",
      appliedDate: "2024-01-20",
      status: "Applied",
      statusColor: "bg-blue-500",
      salary: "$110k - $140k",
      jobType: "Full-time",
      notes: "Application submitted",
      nextStep: "Waiting for response",
      interviewDate: null,
    },
    {
      id: 5,
      jobTitle: "Full Stack Developer",
      company: "WebCorp",
      location: "Seattle, WA",
      appliedDate: "2024-01-12",
      status: "Offer Received",
      statusColor: "bg-purple-500",
      salary: "$125k - $155k",
      jobType: "Full-time",
      notes: "Negotiating salary and benefits",
      nextStep: "Decision deadline: Jan 30",
      interviewDate: null,
    },
  ]

  const getStatusCount = (status: string) => {
    if (status === "all") return applications.length
    return applications.filter((app) => app.status.toLowerCase().replace(" ", "-") === status).length
  }

  const filteredApplications = applications.filter((app) => {
    const matchesSearch =
      app.jobTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      app.company.toLowerCase().includes(searchQuery.toLowerCase())

    const matchesStatus = statusFilter === "all" || app.status.toLowerCase().replace(" ", "-") === statusFilter

    return matchesSearch && matchesStatus
  })

  const upcomingInterviews = applications.filter((app) => app.interviewDate)

  const handleViewJob = (jobId: number) => {
    router.push(`/jobs/${jobId}`)
  }

  const handleAddNotes = (applicationId: number) => {
    toast({
      title: "Notes Feature",
      description: "Notes feature will be available soon!",
    })
  }

  const handleAddToCalendar = (interview: any) => {
    toast({
      title: "Calendar Integration",
      description: `Interview for ${interview.jobTitle} added to calendar`,
    })
  }

  const handlePrepareInterview = (interview: any) => {
    toast({
      title: "Interview Prep",
      description: "Opening interview preparation resources...",
    })
  }

  const handleBrowseJobs = () => {
    router.push("/jobs")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-red-50">
      <Header />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2 text-gray-900">My Applications</h1>
          <p className="text-gray-600">Track and manage your job applications</p>
        </div>

        <Tabs defaultValue="applications" className="space-y-6">
          <TabsList className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <TabsTrigger
              value="applications"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white"
            >
              All Applications ({applications.length})
            </TabsTrigger>
            <TabsTrigger
              value="interviews"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white"
            >
              Upcoming Interviews ({upcomingInterviews.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="applications" className="space-y-6">
            {/* Filters */}
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-1 relative">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Search applications..."
                      className="pl-10 border-gray-200 focus:border-orange-500 focus:ring-orange-500"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-full md:w-48 border-gray-200 focus:border-orange-500 focus:ring-orange-500">
                      <SelectValue placeholder="Filter by status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status ({getStatusCount("all")})</SelectItem>
                      <SelectItem value="applied">Applied ({getStatusCount("applied")})</SelectItem>
                      <SelectItem value="under-review">Under Review ({getStatusCount("under-review")})</SelectItem>
                      <SelectItem value="interview-scheduled">
                        Interview Scheduled ({getStatusCount("interview-scheduled")})
                      </SelectItem>
                      <SelectItem value="offer-received">
                        Offer Received ({getStatusCount("offer-received")})
                      </SelectItem>
                      <SelectItem value="rejected">Rejected ({getStatusCount("rejected")})</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            {/* Applications List */}
            <div className="space-y-4">
              {filteredApplications.map((application) => (
                <Card
                  key={application.id}
                  className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white/80 backdrop-blur-sm"
                >
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="text-xl font-semibold text-gray-900">
                            <button
                              onClick={() => handleViewJob(application.id)}
                              className="hover:text-orange-600 transition-colors"
                            >
                              {application.jobTitle}
                            </button>
                          </h3>
                          <div className="flex items-center space-x-2">
                            <div className={`w-2 h-2 rounded-full ${application.statusColor}`} />
                            <Badge
                              variant="secondary"
                              className="bg-gradient-to-r from-orange-100 to-red-100 text-orange-700"
                            >
                              {application.status}
                            </Badge>
                          </div>
                        </div>

                        <div className="flex items-center text-gray-600 mb-3">
                          <Building2 className="h-4 w-4 mr-1" />
                          <span className="mr-4">{application.company}</span>
                          <MapPin className="h-4 w-4 mr-1" />
                          <span className="mr-4">{application.location}</span>
                          <span className="font-medium text-gray-900">{application.salary}</span>
                        </div>

                        <div className="grid md:grid-cols-2 gap-4 text-sm">
                          <div>
                            <p className="text-gray-600 mb-1">Applied Date:</p>
                            <div className="flex items-center">
                              <Calendar className="h-4 w-4 mr-1 text-orange-500" />
                              <span className="font-medium">
                                {new Date(application.appliedDate).toLocaleDateString()}
                              </span>
                            </div>
                          </div>
                          <div>
                            <p className="text-gray-600 mb-1">Next Step:</p>
                            <p className="font-medium text-gray-900">{application.nextStep || "No next steps"}</p>
                          </div>
                        </div>

                        {application.notes && (
                          <div className="mt-3 p-3 bg-orange-50 rounded-lg">
                            <p className="text-sm text-gray-700">
                              <strong>Notes:</strong> {application.notes}
                            </p>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex gap-3 pt-4 border-t border-gray-100">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleViewJob(application.id)}
                        className="border-orange-300 text-orange-600 hover:bg-orange-50"
                      >
                        <Eye className="h-4 w-4 mr-1" />
                        View Job
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleAddNotes(application.id)}
                        className="border-orange-300 text-orange-600 hover:bg-orange-50"
                      >
                        <FileText className="h-4 w-4 mr-1" />
                        Add Notes
                      </Button>
                      {application.status === "Interview Scheduled" && (
                        <Button
                          size="sm"
                          className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white"
                          onClick={() => handlePrepareInterview(application)}
                        >
                          <MessageSquare className="h-4 w-4 mr-1" />
                          Prepare Interview
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}

              {filteredApplications.length === 0 && (
                <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                  <CardContent className="text-center py-12">
                    <div className="text-gray-400 mb-4">
                      <FileText className="h-16 w-16 mx-auto" />
                    </div>
                    <h3 className="text-xl font-semibold text-gray-600 mb-2">No applications found</h3>
                    <p className="text-gray-500 mb-6">
                      {searchQuery || statusFilter !== "all"
                        ? "Try adjusting your search or filters"
                        : "Start applying to jobs to see them here"}
                    </p>
                    <Button
                      onClick={handleBrowseJobs}
                      className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white"
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Browse Jobs
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="interviews" className="space-y-6">
            <div className="space-y-4">
              {upcomingInterviews.map((interview) => (
                <Card
                  key={interview.id}
                  className="border-0 shadow-lg bg-white/80 backdrop-blur-sm border-l-4 border-l-green-500"
                >
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <h3 className="text-xl font-semibold text-gray-900 mb-2">{interview.jobTitle}</h3>
                        <div className="flex items-center text-gray-600 mb-3">
                          <Building2 className="h-4 w-4 mr-1" />
                          <span className="mr-4">{interview.company}</span>
                          <MapPin className="h-4 w-4 mr-1" />
                          <span>{interview.location}</span>
                        </div>
                        <div className="flex items-center text-green-600 font-medium">
                          <Calendar className="h-4 w-4 mr-1" />
                          Interview Date: {new Date(interview.interviewDate!).toLocaleDateString()}
                        </div>
                      </div>
                      <Badge className="bg-green-500 text-white">Interview Scheduled</Badge>
                    </div>

                    <div className="flex gap-3 pt-4 border-t border-gray-100">
                      <Button
                        size="sm"
                        onClick={() => handleAddToCalendar(interview)}
                        className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white"
                      >
                        <Calendar className="h-4 w-4 mr-1" />
                        Add to Calendar
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handlePrepareInterview(interview)}
                        className="border-orange-300 text-orange-600 hover:bg-orange-50"
                      >
                        <MessageSquare className="h-4 w-4 mr-1" />
                        Prepare Interview
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleViewJob(interview.id)}
                        className="border-orange-300 text-orange-600 hover:bg-orange-50"
                      >
                        <Eye className="h-4 w-4 mr-1" />
                        View Job Details
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}

              {upcomingInterviews.length === 0 && (
                <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                  <CardContent className="text-center py-12">
                    <div className="text-gray-400 mb-4">
                      <Calendar className="h-16 w-16 mx-auto" />
                    </div>
                    <h3 className="text-xl font-semibold text-gray-600 mb-2">No upcoming interviews</h3>
                    <p className="text-gray-500 mb-6">Keep applying to jobs to schedule more interviews</p>
                    <Button
                      onClick={handleBrowseJobs}
                      className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white"
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Browse Jobs
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
