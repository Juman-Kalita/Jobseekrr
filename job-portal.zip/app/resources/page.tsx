"use client"

import { Header } from "@/components/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Video, FileText, Download, ExternalLink } from "lucide-react"
import Link from "next/link"

export default function ResourcesPage() {
  const resources = [
    {
      category: "Career Guides",
      icon: BookOpen,
      items: [
        { title: "Resume Writing Guide", type: "PDF", link: "#" },
        { title: "Interview Preparation", type: "Article", link: "#" },
        { title: "Salary Negotiation Tips", type: "PDF", link: "#" },
      ],
    },
    {
      category: "Video Tutorials",
      icon: Video,
      items: [
        { title: "LinkedIn Profile Optimization", type: "Video", link: "#" },
        { title: "Job Search Strategies", type: "Video", link: "#" },
        { title: "Networking Essentials", type: "Video", link: "#" },
      ],
    },
    {
      category: "Templates",
      icon: FileText,
      items: [
        { title: "Resume Templates", type: "Download", link: "#" },
        { title: "Cover Letter Templates", type: "Download", link: "#" },
        { title: "Thank You Email Templates", type: "Download", link: "#" },
      ],
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-red-50">
      <Header />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-4 text-gray-900">Career Resources</h1>
          <p className="text-gray-600">Everything you need to advance your career</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {resources.map((category, index) => (
            <Card
              key={index}
              className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white/80 backdrop-blur-sm"
            >
              <CardHeader>
                <CardTitle className="flex items-center text-gray-900">
                  <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-red-500 rounded-xl flex items-center justify-center mr-3">
                    <category.icon className="h-5 w-5 text-white" />
                  </div>
                  {category.category}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {category.items.map((item, itemIndex) => (
                    <div
                      key={itemIndex}
                      className="flex items-center justify-between p-3 border border-orange-200 rounded-lg hover:bg-orange-50 transition-colors"
                    >
                      <div>
                        <h4 className="font-medium text-gray-900">{item.title}</h4>
                        <Badge variant="outline" className="text-xs border-orange-300 text-orange-600">
                          {item.type}
                        </Badge>
                      </div>
                      <Button size="sm" variant="ghost" className="text-orange-600 hover:bg-orange-100" asChild>
                        <Link href={item.link}>
                          {item.type === "Download" ? (
                            <Download className="h-4 w-4" />
                          ) : (
                            <ExternalLink className="h-4 w-4" />
                          )}
                        </Link>
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
