"use client"

import { useState } from "react"
import Link from "next/link"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Building2,
  Users,
  Eye,
  TrendingUp,
  Plus,
  MapPin,
  DollarSign,
  Clock,
  Star,
  MessageSquare,
  BarChart3,
  Target,
  Award,
  Zap,
} from "lucide-react"

export default function CompanyDashboardPage() {
  const [activeTab, setActiveTab] = useState("overview")

  // Mock company data
  const company = {
    name: "TechCorp Inc.",
    logo: "/placeholder.svg?height=60&width=60",
    industry: "Technology",
    size: "500-1000 employees",
    location: "San Francisco, CA",
    website: "https://techcorp.com",
    profileComplete: 90,
  }

  const stats = [
    {
      label: "Active Jobs",
      value: "12",
      change: "+3 this month",
      icon: Building2,
      color: "text-blue-500",
      bgColor: "bg-blue-500/10",
      trend: "up",
    },
    {
      label: "Total Applications",
      value: "247",
      change: "+18 this week",
      icon: Users,
      color: "text-green-500",
      bgColor: "bg-green-500/10",
      trend: "up",
    },
    {
      label: "Profile Views",
      value: "1,234",
      change: "+5.2% vs last month",
      icon: Eye,
      color: "text-purple-500",
      bgColor: "bg-purple-500/10",
      trend: "up",
    },
    {
      label: "Hire Rate",
      value: "23%",
      change: "+2% improvement",
      icon: TrendingUp,
      color: "text-orange-500",
      bgColor: "bg-orange-500/10",
      trend: "up",
    },
  ]

  const activeJobs = [
    {
      id: 1,
      title: "Senior Frontend Developer",
      location: "San Francisco, CA",
      type: "Full-time",
      salary: "$120k - $150k",
      posted: "3 days ago",
      applications: 45,
      views: 234,
      status: "Active",
      urgent: false,
    },
    {
      id: 2,
      title: "Product Manager",
      location: "Remote",
      type: "Full-time",
      salary: "$100k - $130k",
      posted: "1 week ago",
      applications: 67,
      views: 189,
      status: "Active",
      urgent: true,
    },
    {
      id: 3,
      title: "UX Designer",
      location: "New York, NY",
      type: "Full-time",
      salary: "$80k - $100k",
      posted: "2 weeks ago",
      applications: 23,
      views: 156,
      status: "Active",
      urgent: false,
    },
  ]

  const recentApplications = [
    {
      id: 1,
      candidateName: "Sarah Johnson",
      jobTitle: "Senior Frontend Developer",
      appliedDate: "2 hours ago",
      experience: "5+ years",
      status: "New",
      avatar: "/placeholder.svg?height=40&width=40",
      skills: ["React", "TypeScript", "Next.js"],
      matchScore: 95,
    },
    {
      id: 2,
      candidateName: "Michael Chen",
      jobTitle: "Product Manager",
      appliedDate: "5 hours ago",
      experience: "7+ years",
      status: "Reviewed",
      avatar: "/placeholder.svg?height=40&width=40",
      skills: ["Product Strategy", "Analytics", "Agile"],
      matchScore: 88,
    },
    {
      id: 3,
      candidateName: "Emily Davis",
      jobTitle: "UX Designer",
      appliedDate: "1 day ago",
      experience: "4+ years",
      status: "Shortlisted",
      avatar: "/placeholder.svg?height=40&width=40",
      skills: ["Figma", "User Research", "Prototyping"],
      matchScore: 92,
    },
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "New":
        return "bg-blue-500"
      case "Reviewed":
        return "bg-yellow-500"
      case "Shortlisted":
        return "bg-green-500"
      case "Rejected":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8 animate-slide-up">
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 gradient-primary rounded-2xl flex items-center justify-center">
              <Building2 className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gradient">Company Dashboard</h1>
              <p className="text-muted-foreground">Welcome back, {company.name}</p>
            </div>
          </div>
          <Button className="gradient-primary text-white hover-glow" asChild>
            <Link href="/company/post-job">
              <Plus className="h-4 w-4 mr-2" />
              Post New Job
            </Link>
          </Button>
        </div>

        {/* Profile Completion */}
        {company.profileComplete < 100 && (
          <Card className="mb-8 border-orange-200 bg-gradient-to-r from-orange-50 to-yellow-50 dark:from-orange-950/20 dark:to-yellow-950/20 animate-scale-in">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-orange-500/20 rounded-xl flex items-center justify-center">
                    <Target className="h-5 w-5 text-orange-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-orange-800 dark:text-orange-200">
                      Complete Your Company Profile
                    </h3>
                    <p className="text-sm text-orange-600 dark:text-orange-300">
                      {company.profileComplete}% complete - Add more details to attract better candidates
                    </p>
                  </div>
                </div>
                <Button variant="outline" className="border-orange-200 hover:bg-orange-100" asChild>
                  <Link href="/company/profile">Complete Profile</Link>
                </Button>
              </div>
              <Progress value={company.profileComplete} className="h-2" />
            </CardContent>
          </Card>
        )}

        {/* Stats Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card
              key={index}
              className="hover-lift card-beautiful animate-slide-up"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className={`w-12 h-12 ${stat.bgColor} rounded-xl flex items-center justify-center`}>
                    <stat.icon className={`h-6 w-6 ${stat.color}`} />
                  </div>
                  <Badge variant="secondary" className="gradient-success text-white">
                    {stat.trend === "up" ? "↗" : "↘"} {stat.change}
                  </Badge>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">{stat.label}</p>
                  <p className="text-3xl font-bold text-gradient">{stat.value}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 glass">
            <TabsTrigger
              value="overview"
              className="data-[state=active]:gradient-primary data-[state=active]:text-white"
            >
              <BarChart3 className="h-4 w-4 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="jobs" className="data-[state=active]:gradient-primary data-[state=active]:text-white">
              <Building2 className="h-4 w-4 mr-2" />
              Active Jobs
            </TabsTrigger>
            <TabsTrigger
              value="applications"
              className="data-[state=active]:gradient-primary data-[state=active]:text-white"
            >
              <Users className="h-4 w-4 mr-2" />
              Applications
            </TabsTrigger>
            <TabsTrigger
              value="analytics"
              className="data-[state=active]:gradient-primary data-[state=active]:text-white"
            >
              <TrendingUp className="h-4 w-4 mr-2" />
              Analytics
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-8">
              {/* Quick Actions */}
              <Card className="card-beautiful">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Zap className="h-5 w-5 mr-2 text-yellow-500" />
                    Quick Actions
                  </CardTitle>
                  <CardDescription>Common tasks to manage your hiring</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button className="w-full justify-start gradient-primary text-white hover-glow" asChild>
                    <Link href="/company/post-job">
                      <Plus className="h-4 w-4 mr-2" />
                      Post a New Job
                    </Link>
                  </Button>
                  <Button variant="outline" className="w-full justify-start hover-lift" asChild>
                    <Link href="/company/applications">
                      <Users className="h-4 w-4 mr-2" />
                      Review Applications
                    </Link>
                  </Button>
                  <Button variant="outline" className="w-full justify-start hover-lift" asChild>
                    <Link href="/company/profile">
                      <Building2 className="h-4 w-4 mr-2" />
                      Update Company Profile
                    </Link>
                  </Button>
                  <Button variant="outline" className="w-full justify-start hover-lift" asChild>
                    <Link href="/company/analytics">
                      <BarChart3 className="h-4 w-4 mr-2" />
                      View Detailed Analytics
                    </Link>
                  </Button>
                </CardContent>
              </Card>

              {/* Recent Activity */}
              <Card className="card-beautiful">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Clock className="h-5 w-5 mr-2 text-blue-500" />
                    Recent Activity
                  </CardTitle>
                  <CardDescription>Latest updates on your job postings</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-3 p-3 rounded-lg bg-blue-50 dark:bg-blue-950/20">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">New application received</p>
                      <p className="text-xs text-muted-foreground">Senior Frontend Developer • 2 hours ago</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 rounded-lg bg-green-50 dark:bg-green-950/20">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">Job posting approved</p>
                      <p className="text-xs text-muted-foreground">Product Manager • 5 hours ago</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 rounded-lg bg-purple-50 dark:bg-purple-950/20">
                    <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">Profile viewed 15 times</p>
                      <p className="text-xs text-muted-foreground">Company profile • 1 day ago</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="jobs" className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-2xl font-semibold text-gradient">Active Job Postings</h3>
              <Button className="gradient-primary text-white hover-glow" asChild>
                <Link href="/company/post-job">
                  <Plus className="h-4 w-4 mr-2" />
                  Post New Job
                </Link>
              </Button>
            </div>

            <div className="grid gap-6">
              {activeJobs.map((job, index) => (
                <Card
                  key={job.id}
                  className="hover-lift card-beautiful animate-slide-up"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h4 className="text-xl font-semibold">{job.title}</h4>
                          {job.urgent && <Badge className="gradient-danger text-white animate-pulse">URGENT</Badge>}
                          <Badge variant="secondary" className="gradient-success text-white">
                            {job.status}
                          </Badge>
                        </div>

                        <div className="flex items-center text-muted-foreground mb-4">
                          <MapPin className="h-4 w-4 mr-1" />
                          <span className="mr-4">{job.location}</span>
                          <DollarSign className="h-4 w-4 mr-1" />
                          <span className="mr-4 font-medium text-foreground">{job.salary}</span>
                          <Clock className="h-4 w-4 mr-1" />
                          <span>Posted {job.posted}</span>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div className="flex items-center">
                            <Users className="h-4 w-4 mr-2 text-blue-500" />
                            <span>
                              <strong>{job.applications}</strong> applications
                            </span>
                          </div>
                          <div className="flex items-center">
                            <Eye className="h-4 w-4 mr-2 text-green-500" />
                            <span>
                              <strong>{job.views}</strong> views
                            </span>
                          </div>
                          <div className="flex items-center">
                            <Star className="h-4 w-4 mr-2 text-yellow-500" />
                            <span>
                              <strong>4.8</strong> rating
                            </span>
                          </div>
                          <div className="flex items-center">
                            <MessageSquare className="h-4 w-4 mr-2 text-purple-500" />
                            <span>
                              <strong>12</strong> messages
                            </span>
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-col space-y-2 ml-4">
                        <Button size="sm" className="gradient-primary text-white hover-glow" asChild>
                          <Link href={`/company/jobs/${job.id}/applications`}>View Applications</Link>
                        </Button>
                        <Button variant="outline" size="sm" className="hover-lift" asChild>
                          <Link href={`/company/jobs/${job.id}/edit`}>Edit Job</Link>
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="applications" className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-2xl font-semibold text-gradient">Recent Applications</h3>
              <Button variant="outline" className="glass hover-lift" asChild>
                <Link href="/company/applications">View All Applications</Link>
              </Button>
            </div>

            <div className="grid gap-4">
              {recentApplications.map((application, index) => (
                <Card
                  key={application.id}
                  className="hover-lift card-beautiful animate-slide-up"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                          <span className="text-white font-bold text-lg">{application.candidateName.charAt(0)}</span>
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-1">
                            <h4 className="font-semibold">{application.candidateName}</h4>
                            <Badge variant="secondary" className={`${getStatusColor(application.status)} text-white`}>
                              {application.status}
                            </Badge>
                            <Badge variant="outline" className="gradient-success text-white">
                              {application.matchScore}% match
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">
                            Applied for {application.jobTitle} • {application.experience} experience
                          </p>
                          <div className="flex flex-wrap gap-1">
                            {application.skills.map((skill) => (
                              <Badge key={skill} variant="outline" className="text-xs">
                                {skill}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        <span className="text-xs text-muted-foreground">{application.appliedDate}</span>
                        <Button size="sm" className="gradient-primary text-white hover-glow">
                          Review
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card className="card-beautiful">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Award className="h-5 w-5 mr-2 text-yellow-500" />
                    Top Performing Job
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <p className="font-semibold">Senior Frontend Developer</p>
                    <p className="text-sm text-muted-foreground">45 applications in 3 days</p>
                    <Progress value={85} className="h-2" />
                    <p className="text-xs text-muted-foreground">85% above average</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="card-beautiful">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <TrendingUp className="h-5 w-5 mr-2 text-green-500" />
                    Application Trend
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <p className="text-2xl font-bold text-gradient">+23%</p>
                    <p className="text-sm text-muted-foreground">vs last month</p>
                    <div className="flex items-center text-green-600 text-sm">
                      <TrendingUp className="h-4 w-4 mr-1" />
                      <span>Trending up</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="card-beautiful">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Users className="h-5 w-5 mr-2 text-blue-500" />
                    Avg. Time to Hire
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <p className="text-2xl font-bold text-gradient">12 days</p>
                    <p className="text-sm text-muted-foreground">3 days faster than average</p>
                    <div className="flex items-center text-green-600 text-sm">
                      <TrendingUp className="h-4 w-4 mr-1" />
                      <span>Improved efficiency</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
