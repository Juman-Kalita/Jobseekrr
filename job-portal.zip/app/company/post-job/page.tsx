"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Plus, X, Building2, MapPin, DollarSign, Clock, Briefcase, Star, Eye, Save, Send, Upload } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation"
import { useForm, Controller } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import * as z from "zod"
import { cn } from "@/lib/utils"
import { Skeleton } from "@/components/ui/skeleton"
import Image from "next/image"

const FormSchema = z.object({
  title: z.string().min(2, {
    message: "Job title must be at least 2 characters.",
  }),
  department: z.string().optional(),
  location: z.string().min(2, {
    message: "Location must be at least 2 characters.",
  }),
  jobType: z.string().min(2, {
    message: "Job type must be selected.",
  }),
  experienceLevel: z.string().min(2, {
    message: "Experience level must be selected.",
  }),
  salaryMin: z.string().optional(),
  salaryMax: z.string().optional(),
  currency: z.string().optional(),
  description: z.string().min(10, {
    message: "Job description must be at least 10 characters.",
  }),
  requirements: z.string().min(10, {
    message: "Job requirements must be at least 10 characters.",
  }),
  responsibilities: z.string().optional(),
  companyDescription: z.string().optional(),
  applicationDeadline: z.string().optional(),
  startDate: z.string().optional(),
  remote: z.boolean().default(false),
  urgent: z.boolean().default(false),
  featured: z.boolean().default(false),
  skills: z.array(z.string()).default([]),
  benefits: z.array(z.string()).default([]),
  companyLogo: z.string().optional(),
})

type FormValues = z.infer<typeof FormSchema>

export default function PostJobPage() {
  const router = useRouter()
  const { data: session, status } = useSession()
  const [isLoading, setIsLoading] = useState(false)
  const [isLogoUploading, setIsLogoUploading] = useState(false)
  const [logoPreview, setLogoPreview] = useState<string | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/sign-in")
    }
  }, [status, router])

  const {
    control,
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm<FormValues>({
    resolver: zodResolver(FormSchema),
    defaultValues: {
      title: "",
      department: "",
      location: "",
      jobType: "",
      experienceLevel: "",
      salaryMin: "",
      salaryMax: "",
      currency: "USD",
      description: "",
      requirements: "",
      responsibilities: "",
      companyDescription: "",
      applicationDeadline: "",
      startDate: "",
      remote: false,
      urgent: false,
      featured: false,
      skills: [],
      benefits: [],
      companyLogo: null,
    },
  })

  const skills = watch("skills")
  const benefits = watch("benefits")

  const [newSkill, setNewSkill] = useState("")
  const [newBenefit, setNewBenefit] = useState("")

  const jobTypes = ["Full-time", "Part-time", "Contract", "Freelance", "Internship"]
  const experienceLevels = ["Entry Level", "1-2 years", "3-5 years", "5-10 years", "10+ years"]
  const departments = ["Engineering", "Product", "Design", "Marketing", "Sales", "HR", "Finance", "Operations"]
  const currencies = ["USD", "EUR", "GBP", "CAD", "AUD"]

  const commonSkills = [
    "JavaScript",
    "React",
    "Node.js",
    "Python",
    "Java",
    "TypeScript",
    "AWS",
    "Docker",
    "Product Management",
    "Agile",
    "Scrum",
    "Analytics",
    "Figma",
    "Sketch",
    "Adobe Creative Suite",
    "Marketing",
    "SEO",
    "Content Strategy",
    "Social Media",
    "Sales",
    "CRM",
    "Leadership",
  ]

  const commonBenefits = [
    "Health Insurance",
    "Dental Insurance",
    "Vision Insurance",
    "401(k)",
    "Flexible PTO",
    "Remote Work",
    "Flexible Hours",
    "Professional Development",
    "Stock Options",
    "Gym Membership",
    "Free Lunch",
    "Commuter Benefits",
    "Parental Leave",
    "Mental Health Support",
  ]

  const addSkill = (skill: string) => {
    if (skill.trim() && !skills.includes(skill.trim())) {
      setValue("skills", [...skills, skill.trim()])
      setNewSkill("")
    }
  }

  const removeSkill = (skillToRemove: string) => {
    setValue(
      "skills",
      skills.filter((skill) => skill !== skillToRemove),
    )
  }

  const addBenefit = (benefit: string) => {
    if (benefit.trim() && !benefits.includes(benefit.trim())) {
      setValue("benefits", [...benefits, benefit.trim()])
      setNewBenefit("")
    }
  }

  const removeBenefit = (benefitToRemove: string) => {
    setValue(
      "benefits",
      benefits.filter((benefit) => benefit !== benefitToRemove),
    )
  }

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setIsLogoUploading(true)

    const reader = new FileReader()
    reader.onloadend = () => {
      setLogoPreview(reader.result as string)
    }
    reader.readAsDataURL(file)

    // Simulate upload and get URL
    setTimeout(() => {
      const logoUrl = "https://via.placeholder.com/150" // Replace with actual upload logic
      setValue("companyLogo", logoUrl)
      setIsLogoUploading(false)
    }, 1000)
  }

  const onSubmit = async (data: FormValues, action: "draft" | "publish") => {
    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      setIsLoading(false)
      toast({
        title: action === "draft" ? "Job Saved as Draft" : "Job Posted Successfully!",
        description:
          action === "draft"
            ? "Your job posting has been saved and can be published later."
            : "Your job posting is now live and candidates can apply.",
      })
    }, 1000)
  }

  if (status === "loading") {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <Skeleton className="w-[200px] h-[40px]" />
          <Skeleton className="w-[300px] h-[30px] mt-4" />
          <div className="grid lg:grid-cols-3 gap-8 mt-8">
            <div className="lg:col-span-2 space-y-8">
              <Card className="card-beautiful">
                <CardHeader>
                  <CardTitle>
                    <Skeleton className="w-[200px] h-[30px]" />
                  </CardTitle>
                  <CardDescription>
                    <Skeleton className="w-[250px] h-[20px]" />
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <Skeleton className="w-full h-[40px]" />
                  <Skeleton className="w-full h-[40px]" />
                  <Skeleton className="w-full h-[40px]" />
                </CardContent>
              </Card>
              <Card className="card-beautiful">
                <CardHeader>
                  <CardTitle>
                    <Skeleton className="w-[200px] h-[30px]" />
                  </CardTitle>
                  <CardDescription>
                    <Skeleton className="w-[250px] h-[20px]" />
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <Skeleton className="w-full h-[40px]" />
                  <Skeleton className="w-full h-[40px]" />
                  <Skeleton className="w-full h-[40px]" />
                </CardContent>
              </Card>
            </div>
            <div className="lg:col-span-1 space-y-6">
              <Card className="card-beautiful">
                <CardHeader>
                  <CardTitle>
                    <Skeleton className="w-[100px] h-[30px]" />
                  </CardTitle>
                  <CardDescription>
                    <Skeleton className="w-[150px] h-[20px]" />
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Skeleton className="w-full h-[150px]" />
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8 animate-slide-up">
          <div className="flex items-center mb-4">
            <div className="w-12 h-12 gradient-primary rounded-xl flex items-center justify-center mr-4">
              <Plus className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gradient">Post a New Job</h1>
              <p className="text-muted-foreground">Create an attractive job posting to find the best candidates</p>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Form */}
          <div className="lg:col-span-2 space-y-8">
            {/* Basic Information */}
            <Card className="card-beautiful animate-scale-in">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Briefcase className="h-5 w-5 mr-2 text-blue-500" />
                  Basic Information
                </CardTitle>
                <CardDescription>Essential details about the position</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">Job Title *</Label>
                    <Input
                      id="title"
                      placeholder="e.g. Senior Frontend Developer"
                      className={cn("focus-beautiful", errors.title && "border-red-500")}
                      {...register("title")}
                    />
                    {errors?.title && <p className="text-red-500 text-sm">{errors.title.message}</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="department">Department</Label>
                    <Controller
                      control={control}
                      name="department"
                      render={({ field }) => (
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select department" />
                          </SelectTrigger>
                          <SelectContent>
                            {departments.map((dept) => (
                              <SelectItem key={dept} value={dept}>
                                {dept}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      )}
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="location">Location *</Label>
                    <Input
                      id="location"
                      placeholder="e.g. San Francisco, CA or Remote"
                      className={cn("focus-beautiful", errors.location && "border-red-500")}
                      {...register("location")}
                    />
                    {errors?.location && <p className="text-red-500 text-sm">{errors.location.message}</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="jobType">Job Type *</Label>
                    <Controller
                      control={control}
                      name="jobType"
                      render={({ field }) => (
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <SelectTrigger className={cn(errors.jobType && "border-red-500")}>
                            <SelectValue placeholder="Select job type" />
                          </SelectTrigger>
                          <SelectContent>
                            {jobTypes.map((type) => (
                              <SelectItem key={type} value={type}>
                                {type}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      )}
                    />
                    {errors?.jobType && <p className="text-red-500 text-sm">{errors.jobType.message}</p>}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="experienceLevel">Experience Level *</Label>
                  <Controller
                    control={control}
                    name="experienceLevel"
                    render={({ field }) => (
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <SelectTrigger className={cn(errors.experienceLevel && "border-red-500")}>
                          <SelectValue placeholder="Select experience level" />
                        </SelectTrigger>
                        <SelectContent>
                          {experienceLevels.map((level) => (
                            <SelectItem key={level} value={level}>
                              {level}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  />
                  {errors?.experienceLevel && <p className="text-red-500 text-sm">{errors.experienceLevel.message}</p>}
                </div>

                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="remote"
                      checked={watch("remote")}
                      onCheckedChange={(checked) => setValue("remote", checked as boolean)}
                    />
                    <Label htmlFor="remote">Remote work available</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="urgent"
                      checked={watch("urgent")}
                      onCheckedChange={(checked) => setValue("urgent", checked as boolean)}
                    />
                    <Label htmlFor="urgent">Urgent hiring</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="featured"
                      checked={watch("featured")}
                      onCheckedChange={(checked) => setValue("featured", checked as boolean)}
                    />
                    <Label htmlFor="featured">Featured posting (+$50)</Label>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="companyLogo">Company Logo</Label>
                  <div className="flex items-center space-x-4">
                    <Input
                      id="companyLogo"
                      type="file"
                      accept="image/*"
                      onChange={handleLogoUpload}
                      className="hidden"
                      {...register("companyLogo")}
                    />
                    <Label
                      htmlFor="companyLogo"
                      className="cursor-pointer bg-secondary hover:bg-secondary/80 text-secondary-foreground rounded-md px-3 py-2 font-semibold"
                    >
                      {isLogoUploading ? "Uploading..." : "Upload Logo"}
                      <Upload className="h-4 w-4 ml-2 inline-block" />
                    </Label>
                    {logoPreview && (
                      <div className="relative w-20 h-20 rounded-full overflow-hidden">
                        <Image
                          src={logoPreview || "/placeholder.svg"}
                          alt="Company Logo Preview"
                          fill
                          className="object-cover"
                        />
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Compensation */}
            <Card className="card-beautiful animate-scale-in" style={{ animationDelay: "0.1s" }}>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <DollarSign className="h-5 w-5 mr-2 text-green-500" />
                  Compensation
                </CardTitle>
                <CardDescription>Salary range and benefits information</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="currency">Currency</Label>
                    <Controller
                      control={control}
                      name="currency"
                      render={({ field }) => (
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {currencies.map((currency) => (
                              <SelectItem key={currency} value={currency}>
                                {currency}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      )}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="salaryMin">Minimum Salary</Label>
                    <Input
                      id="salaryMin"
                      type="number"
                      placeholder="80000"
                      className="focus-beautiful"
                      {...register("salaryMin")}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="salaryMax">Maximum Salary</Label>
                    <Input
                      id="salaryMax"
                      type="number"
                      placeholder="120000"
                      className="focus-beautiful"
                      {...register("salaryMax")}
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>Benefits & Perks</Label>
                    <div className="flex gap-2">
                      <Input
                        placeholder="Add custom benefit"
                        value={newBenefit}
                        onChange={(e) => setNewBenefit(e.target.value)}
                        onKeyPress={(e) => e.key === "Enter" && addBenefit(newBenefit)}
                        className="w-48"
                      />
                      <Button size="sm" onClick={() => addBenefit(newBenefit)}>
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="flex flex-wrap gap-2">
                      {commonBenefits.map((benefit) => (
                        <Badge
                          key={benefit}
                          variant={benefits.includes(benefit) ? "default" : "outline"}
                          className={`cursor-pointer transition-all ${
                            benefits.includes(benefit)
                              ? "gradient-primary text-white"
                              : "hover:bg-primary hover:text-white"
                          }`}
                          onClick={() => (benefits.includes(benefit) ? removeBenefit(benefit) : addBenefit(benefit))}
                        >
                          {benefit}
                        </Badge>
                      ))}
                    </div>

                    {benefits.length > 0 && (
                      <div className="space-y-2">
                        <Label>Selected Benefits:</Label>
                        <div className="flex flex-wrap gap-2">
                          {benefits.map((benefit) => (
                            <Badge key={benefit} className="gradient-success text-white">
                              {benefit}
                              <button
                                onClick={() => removeBenefit(benefit)}
                                className="ml-2 hover:bg-white/20 rounded-full p-0.5"
                              >
                                <X className="h-3 w-3" />
                              </button>
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Job Description */}
            <Card className="card-beautiful animate-scale-in" style={{ animationDelay: "0.2s" }}>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Building2 className="h-5 w-5 mr-2 text-purple-500" />
                  Job Description
                </CardTitle>
                <CardDescription>Detailed information about the role and company</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="description">Job Description *</Label>
                  <Textarea
                    id="description"
                    placeholder="Describe the role, what the candidate will be doing, and what makes this opportunity exciting..."
                    rows={6}
                    className={cn("focus-beautiful", errors.description && "border-red-500")}
                    {...register("description")}
                  />
                  {errors?.description && <p className="text-red-500 text-sm">{errors.description.message}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="responsibilities">Key Responsibilities</Label>
                  <Textarea
                    id="responsibilities"
                    placeholder="• Lead frontend development initiatives&#10;• Collaborate with design and backend teams&#10;• Mentor junior developers..."
                    rows={4}
                    className="focus-beautiful"
                    {...register("responsibilities")}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="requirements">Requirements & Qualifications *</Label>
                  <Textarea
                    id="requirements"
                    placeholder="• 5+ years of frontend development experience&#10;• Expert knowledge of React and TypeScript&#10;• Experience with modern development tools..."
                    rows={4}
                    className={cn("focus-beautiful", errors.requirements && "border-red-500")}
                    {...register("requirements")}
                  />
                  {errors?.requirements && <p className="text-red-500 text-sm">{errors.requirements.message}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="companyDescription">About the Company</Label>
                  <Textarea
                    id="companyDescription"
                    placeholder="Tell candidates about your company culture, mission, and what makes it a great place to work..."
                    rows={3}
                    className="focus-beautiful"
                    {...register("companyDescription")}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Skills & Requirements */}
            <Card className="card-beautiful animate-scale-in" style={{ animationDelay: "0.3s" }}>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Star className="h-5 w-5 mr-2 text-yellow-500" />
                  Skills & Technologies
                </CardTitle>
                <CardDescription>Required and preferred skills for this position</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>Required Skills</Label>
                    <div className="flex gap-2">
                      <Input
                        placeholder="Add custom skill"
                        value={newSkill}
                        onChange={(e) => setNewSkill(e.target.value)}
                        onKeyPress={(e) => e.key === "Enter" && addSkill(newSkill)}
                        className="w-48"
                      />
                      <Button size="sm" onClick={() => addSkill(newSkill)}>
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="flex flex-wrap gap-2">
                      {commonSkills.map((skill) => (
                        <Badge
                          key={skill}
                          variant={skills.includes(skill) ? "default" : "outline"}
                          className={`cursor-pointer transition-all ${
                            skills.includes(skill) ? "gradient-primary text-white" : "hover:bg-primary hover:text-white"
                          }`}
                          onClick={() => (skills.includes(skill) ? removeSkill(skill) : addSkill(skill))}
                        >
                          {skill}
                        </Badge>
                      ))}
                    </div>

                    {skills.length > 0 && (
                      <div className="space-y-2">
                        <Label>Selected Skills:</Label>
                        <div className="flex flex-wrap gap-2">
                          {skills.map((skill) => (
                            <Badge key={skill} className="gradient-success text-white">
                              {skill}
                              <button
                                onClick={() => removeSkill(skill)}
                                className="ml-2 hover:bg-white/20 rounded-full p-0.5"
                              >
                                <X className="h-3 w-3" />
                              </button>
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Timeline */}
            <Card className="card-beautiful animate-scale-in" style={{ animationDelay: "0.4s" }}>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Clock className="h-5 w-5 mr-2 text-orange-500" />
                  Timeline
                </CardTitle>
                <CardDescription>Important dates for this position</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="applicationDeadline">Application Deadline</Label>
                    <Input
                      id="applicationDeadline"
                      type="date"
                      className="focus-beautiful"
                      {...register("applicationDeadline")}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="startDate">Expected Start Date</Label>
                    <Input id="startDate" type="date" className="focus-beautiful" {...register("startDate")} />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            {/* Preview */}
            <Card className="card-beautiful sticky top-24 animate-slide-up">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Eye className="h-5 w-5 mr-2 text-blue-500" />
                  Preview
                </CardTitle>
                <CardDescription>How your job posting will appear</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 border rounded-lg bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-950/20 dark:to-purple-950/20">
                  {watch("companyLogo") && (
                    <div className="relative w-20 h-20 rounded-full overflow-hidden mb-3">
                      <Image src={watch("companyLogo") || ""} alt="Company Logo" fill className="object-cover" />
                    </div>
                  )}
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h4 className="font-semibold text-lg">{watch("title") || "Job Title"}</h4>
                      <p className="text-sm text-muted-foreground">TechCorp Inc.</p>
                    </div>
                    <div className="flex flex-col gap-1">
                      {watch("urgent") && <Badge className="gradient-danger text-white text-xs">URGENT</Badge>}
                      {watch("featured") && <Badge className="gradient-warning text-white text-xs">⭐ FEATURED</Badge>}
                    </div>
                  </div>

                  <div className="space-y-2 text-sm text-muted-foreground">
                    <div className="flex items-center">
                      <MapPin className="h-3 w-3 mr-1" />
                      <span>{watch("location") || "Location"}</span>
                      {watch("remote") && (
                        <Badge variant="secondary" className="ml-2 text-xs">
                          Remote
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center">
                      <DollarSign className="h-3 w-3 mr-1" />
                      <span>
                        {watch("salaryMin") && watch("salaryMax")
                          ? `${watch("currency")} ${watch("salaryMin")} - ${watch("salaryMax")}`
                          : "Salary range"}
                      </span>
                    </div>
                    <div className="flex items-center">
                      <Briefcase className="h-3 w-3 mr-1" />
                      <span>{watch("jobType") || "Job type"}</span>
                    </div>
                  </div>

                  {skills.length > 0 && (
                    <div className="mt-3">
                      <div className="flex flex-wrap gap-1">
                        {skills.slice(0, 3).map((skill) => (
                          <Badge key={skill} variant="outline" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                        {skills.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{skills.length - 3} more
                          </Badge>
                        )}
                      </div>
                    </div>
                  )}
                </div>

                <div className="text-xs text-muted-foreground space-y-1">
                  <p>• Job will be visible to all job seekers</p>
                  <p>• Applications will be sent to your dashboard</p>
                  <p>• You can edit or pause anytime</p>
                </div>
              </CardContent>
            </Card>

            {/* Pricing */}
            <Card className="card-beautiful animate-slide-up" style={{ animationDelay: "0.1s" }}>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <DollarSign className="h-5 w-5 mr-2 text-green-500" />
                  Pricing
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span>Standard Job Posting</span>
                    <span className="font-semibold">$99</span>
                  </div>
                  {watch("featured") && (
                    <div className="flex items-center justify-between">
                      <span>Featured Listing</span>
                      <span className="font-semibold">$50</span>
                    </div>
                  )}
                  <Separator />
                  <div className="flex items-center justify-between font-semibold">
                    <span>Total</span>
                    <span className="text-lg">${watch("featured") ? "149" : "99"}</span>
                  </div>
                </div>

                <div className="text-xs text-muted-foreground">
                  <p>• 30-day listing duration</p>
                  <p>• Unlimited applications</p>
                  <p>• Analytics dashboard</p>
                  <p>• Email notifications</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between mt-12 p-6 glass rounded-2xl animate-fade-in">
          <div className="text-sm text-muted-foreground">
            <p>Your job posting will be reviewed within 24 hours</p>
          </div>
          <div className="flex items-center space-x-4">
            <Button
              variant="outline"
              size="lg"
              className="hover-lift"
              onClick={handleSubmit((data) => onSubmit(data, "draft"))}
              disabled={isLoading}
            >
              <Save className="h-4 w-4 mr-2" />
              Save as Draft
            </Button>
            <Button
              size="lg"
              className="gradient-primary text-white hover-glow"
              onClick={handleSubmit((data) => onSubmit(data, "publish"))}
              disabled={isLoading}
            >
              <Send className="h-4 w-4 mr-2" />
              {isLoading ? "Publishing..." : "Publish Job"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
