"use client"

import { useState, useEffect } from "react"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, MapPin, Building2, Clock, Heart, Eye, Share2, Trash2, Plus, Filter } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"

export default function SavedJobsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [locationFilter, setLocationFilter] = useState("")
  const [jobTypeFilter, setJobTypeFilter] = useState("")
  const [sortOrder, setSortOrder] = useState("recent")
  const [savedJobs, setSavedJobs] = useState([])
  const { toast } = useToast()
  const router = useRouter()

  // Mock saved jobs data
  const mockSavedJobs = [
    {
      id: 1,
      title: "Senior Frontend Developer",
      company: "TechCorp Inc.",
      location: "New York, NY",
      type: "Full-time",
      salary: "80k-120k",
      savedDate: "2024-01-20",
      urgent: true,
      description: "We're looking for a senior frontend developer to join our growing team.",
    },
    {
      id: 2,
      title: "Full Stack Engineer",
      company: "StartupXYZ",
      location: "San Francisco, CA",
      type: "Full-time",
      salary: "90k-140k",
      savedDate: "2024-01-18",
      urgent: false,
      description: "Join our innovative startup and help build the next generation of web applications.",
    },
    {
      id: 3,
      title: "React Developer",
      company: "Digital Agency",
      location: "Chicago, IL",
      type: "Contract",
      salary: "60k-90k",
      savedDate: "2024-01-15",
      urgent: false,
      description: "Work with a creative team to build beautiful user interfaces.",
    },
  ]

  useEffect(() => {
    // Load saved jobs from localStorage
    const saved = localStorage.getItem("savedJobs")
    if (saved) {
      const savedIds = JSON.parse(saved)
      const savedJobsData = mockSavedJobs.filter((job) => savedIds.includes(job.id))
      setSavedJobs(savedJobsData)
    }
  }, [])

  const filteredJobs = savedJobs.filter((job) => {
    const matchesSearch =
      job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.company.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesLocation = !locationFilter || locationFilter === "any" || job.location.includes(locationFilter)
    const matchesType = !jobTypeFilter || jobTypeFilter === "any" || job.type === jobTypeFilter

    return matchesSearch && matchesLocation && matchesType
  })

  const sortedJobs = [...filteredJobs].sort((a, b) => {
    if (sortOrder === "recent") return new Date(b.savedDate).getTime() - new Date(a.savedDate).getTime()
    if (sortOrder === "title") return a.title.localeCompare(b.title)
    if (sortOrder === "company") return a.company.localeCompare(b.company)
    return 0
  })

  const handleRemoveJob = (jobId: number) => {
    const job = savedJobs.find((j) => j.id === jobId)
    setSavedJobs(savedJobs.filter((job) => job.id !== jobId))

    // Update localStorage
    const currentSaved = JSON.parse(localStorage.getItem("savedJobs") || "[]")
    const updatedSaved = currentSaved.filter((id: number) => id !== jobId)
    localStorage.setItem("savedJobs", JSON.stringify(updatedSaved))

    toast({
      title: "Job Removed",
      description: `${job?.title} removed from saved jobs`,
    })
  }

  const handleViewJob = (jobId: number) => {
    router.push(`/jobs/${jobId}`)
  }

  const handleShareJob = (job: any) => {
    const jobUrl = `${window.location.origin}/jobs/${job.id}`
    navigator.clipboard.writeText(jobUrl)
    toast({
      title: "Link Copied",
      description: `Share link for ${job.title} copied to clipboard`,
    })
  }

  const handleApplyToJob = (jobId: number) => {
    const job = savedJobs.find((j) => j.id === jobId)
    toast({
      title: "Redirecting to Application",
      description: `Opening application for ${job?.title}`,
    })
    router.push(`/jobs/${jobId}`)
  }

  const handleBrowseJobs = () => {
    router.push("/jobs")
  }

  const handleClearFilters = () => {
    setSearchQuery("")
    setLocationFilter("")
    setJobTypeFilter("")
    setSortOrder("recent")
    toast({
      title: "Filters Cleared",
      description: "All filters have been reset",
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-red-50">
      <Header />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2 text-gray-900">Saved Jobs</h1>
              <p className="text-gray-600">
                You have {savedJobs.length} saved job{savedJobs.length !== 1 ? "s" : ""}
              </p>
            </div>
            <div className="flex gap-3">
              <Button
                variant="outline"
                className="border-orange-300 text-orange-600 hover:bg-orange-50"
                onClick={handleClearFilters}
              >
                <Filter className="h-4 w-4 mr-2" />
                Clear Filters
              </Button>
              <Button
                onClick={handleBrowseJobs}
                className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white"
              >
                <Plus className="h-4 w-4 mr-2" />
                Browse More Jobs
              </Button>
            </div>
          </div>
        </div>

        {savedJobs.length > 0 && (
          <Card className="mb-6 border-0 shadow-lg bg-white/80 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="grid md:grid-cols-4 gap-4">
                {/* Search */}
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search saved jobs..."
                    className="pl-10 border-gray-200 focus:border-orange-500 focus:ring-orange-500"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>

                {/* Location Filter */}
                <Select value={locationFilter} onValueChange={setLocationFilter}>
                  <SelectTrigger className="border-gray-200 focus:border-orange-500">
                    <SelectValue placeholder="Any location" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="any">Any location</SelectItem>
                    <SelectItem value="New York">New York</SelectItem>
                    <SelectItem value="San Francisco">San Francisco</SelectItem>
                    <SelectItem value="Chicago">Chicago</SelectItem>
                  </SelectContent>
                </Select>

                {/* Job Type Filter */}
                <Select value={jobTypeFilter} onValueChange={setJobTypeFilter}>
                  <SelectTrigger className="border-gray-200 focus:border-orange-500">
                    <SelectValue placeholder="Any type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="any">Any type</SelectItem>
                    <SelectItem value="Full-time">Full-time</SelectItem>
                    <SelectItem value="Part-time">Part-time</SelectItem>
                    <SelectItem value="Contract">Contract</SelectItem>
                  </SelectContent>
                </Select>

                {/* Sort Order */}
                <Select value={sortOrder} onValueChange={setSortOrder}>
                  <SelectTrigger className="border-gray-200 focus:border-orange-500">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="recent">Recently Saved</SelectItem>
                    <SelectItem value="title">Job Title</SelectItem>
                    <SelectItem value="company">Company Name</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        )}

        {sortedJobs.length === 0 ? (
          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
            <CardContent className="text-center py-12">
              <div className="text-gray-400 mb-4">
                <Heart className="h-16 w-16 mx-auto" />
              </div>
              <h3 className="text-xl font-semibold text-gray-600 mb-2">
                {savedJobs.length === 0 ? "No saved jobs yet" : "No jobs match your filters"}
              </h3>
              <p className="text-gray-500 mb-6">
                {savedJobs.length === 0
                  ? "Start saving jobs you're interested in to see them here"
                  : "Try adjusting your search or filters"}
              </p>
              <div className="flex gap-3 justify-center">
                {savedJobs.length === 0 ? (
                  <Button
                    onClick={handleBrowseJobs}
                    className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Browse Jobs
                  </Button>
                ) : (
                  <Button
                    onClick={handleClearFilters}
                    className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white"
                  >
                    Clear Filters
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {sortedJobs.map((job) => (
              <Card
                key={job.id}
                className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white/80 backdrop-blur-sm"
              >
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <CardTitle className="text-xl font-bold text-gray-800 mb-2">
                        <button
                          onClick={() => handleViewJob(job.id)}
                          className="hover:text-orange-600 transition-colors text-left"
                        >
                          {job.title}
                        </button>
                      </CardTitle>
                      <CardDescription className="flex items-center gap-4 text-gray-600">
                        <span className="flex items-center gap-1">
                          <Building2 className="h-4 w-4" />
                          {job.company}
                        </span>
                        <span className="flex items-center gap-1">
                          <MapPin className="h-4 w-4" />
                          {job.location}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          {job.type}
                        </span>
                      </CardDescription>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary" className="bg-green-100 text-green-800">
                        ${job.salary}
                      </Badge>
                      {job.urgent && <Badge className="bg-red-500 text-white animate-pulse">URGENT</Badge>}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <p className="text-gray-600 mb-4 line-clamp-2">{job.description}</p>

                  <div className="flex items-center justify-between mb-4">
                    <div className="flex gap-2">
                      <Badge variant="outline" className="text-xs border-orange-300 text-orange-600">
                        React
                      </Badge>
                      <Badge variant="outline" className="text-xs border-orange-300 text-orange-600">
                        TypeScript
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-500">Saved on {new Date(job.savedDate).toLocaleDateString()}</p>
                  </div>

                  <div className="flex gap-3">
                    <Button
                      onClick={() => handleApplyToJob(job.id)}
                      className="flex-1 bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white font-semibold"
                    >
                      Apply Now
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => handleViewJob(job.id)}
                      className="border-orange-300 text-orange-600 hover:bg-orange-50"
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => handleShareJob(job)}
                      className="border-orange-300 text-orange-600 hover:bg-orange-50"
                    >
                      <Share2 className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => handleRemoveJob(job.id)}
                      className="border-red-300 text-red-600 hover:bg-red-50"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
