"use client"

import { Header } from "@/components/header"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { TrendingUp, MapPin, Briefcase, Search, Download } from "lucide-react"

export default function SalaryGuidePage() {
  const salaryData = [
    {
      role: "Software Engineer",
      location: "San Francisco, CA",
      experience: "3-5 years",
      salary: "$120,000 - $180,000",
      trend: "+8%",
      companies: 150,
    },
    {
      role: "Product Manager",
      location: "New York, NY",
      experience: "5-8 years",
      salary: "$140,000 - $200,000",
      trend: "+12%",
      companies: 89,
    },
    // Add more salary data...
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-red-50">
      <Header />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <div className="flex items-center space-x-2 mb-4">
            <Badge className="bg-green-100 text-green-700">New</Badge>
            <span className="text-sm text-gray-600">Updated weekly with latest market data</span>
          </div>
          <h1 className="text-3xl font-bold mb-4 text-gray-900">Salary Guide 2024</h1>
          <p className="text-gray-600">Get insights into compensation trends across industries and locations</p>
        </div>

        {/* Search */}
        <Card className="mb-8 border-0 shadow-lg bg-white/80 backdrop-blur-sm">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search job titles..."
                  className="pl-10 border-gray-200 focus:border-orange-500 focus:ring-orange-500"
                />
              </div>
              <Select>
                <SelectTrigger className="w-full md:w-48 border-gray-200 focus:border-orange-500 focus:ring-orange-500">
                  <SelectValue placeholder="Location" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sf">San Francisco, CA</SelectItem>
                  <SelectItem value="ny">New York, NY</SelectItem>
                  <SelectItem value="remote">Remote</SelectItem>
                </SelectContent>
              </Select>
              <Button className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white shadow-lg">
                <Download className="h-4 w-4 mr-2" />
                Download Report
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Salary Data */}
        <div className="space-y-4">
          {salaryData.map((item, index) => (
            <Card
              key={index}
              className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white/80 backdrop-blur-sm"
            >
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg mb-2 text-gray-900">{item.role}</h3>
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 mr-1" />
                        {item.location}
                      </div>
                      <div className="flex items-center">
                        <Briefcase className="h-4 w-4 mr-1" />
                        {item.experience}
                      </div>
                      <span>{item.companies} companies</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-green-600 mb-1">{item.salary}</div>
                    <div className="flex items-center text-sm">
                      <TrendingUp className="h-4 w-4 mr-1 text-green-500" />
                      <span className="text-green-600">{item.trend} vs last year</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  )
}
