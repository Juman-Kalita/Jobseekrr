"use client"

import type React from "react"
import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Briefcase,
  Eye,
  EyeOff,
  User,
  Building2,
  Mail,
  Phone,
  MapPin,
  Globe,
  Users,
  Sparkles,
  CheckCircle,
  ArrowRight,
  Star,
  Award,
  TrendingUp,
} from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { useRouter, useSearchParams } from "next/navigation"

export default function RegisterPage() {
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [activeTab, setActiveTab] = useState<"seeker" | "company">("seeker")
  const { toast } = useToast()
  const router = useRouter()
  const searchParams = useSearchParams()

  useEffect(() => {
    const type = searchParams.get("type")
    if (type === "company") {
      setActiveTab("company")
    } else {
      setActiveTab("seeker")
    }
  }, [searchParams])

  const [seekerData, setSeekerData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    password: "",
    location: "",
    experience: "",
    jobTitle: "",
    skills: [] as string[],
    agreeToTerms: false,
    subscribeNewsletter: true,
  })

  const [companyData, setCompanyData] = useState({
    companyName: "",
    industry: "",
    companySize: "",
    website: "",
    contactName: "",
    contactEmail: "",
    phone: "",
    password: "",
    location: "",
    description: "",
    agreeToTerms: false,
    subscribeNewsletter: true,
  })

  const [seekerErrors, setSeekerErrors] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    password: "",
  })

  const [companyErrors, setCompanyErrors] = useState({
    companyName: "",
    industry: "",
    companySize: "",
    contactName: "",
    contactEmail: "",
    phone: "",
    password: "",
  })

  const industries = [
    "Technology",
    "Healthcare",
    "Finance",
    "Education",
    "Retail",
    "Manufacturing",
    "Consulting",
    "Media",
    "Real Estate",
    "Transportation",
    "Energy",
    "Other",
  ]

  const companySizes = [
    "1-10 employees",
    "11-50 employees",
    "51-200 employees",
    "201-500 employees",
    "501-1000 employees",
    "1000+ employees",
  ]

  const experienceLevels = ["Entry Level", "1-2 years", "3-5 years", "5-10 years", "10+ years"]

  const validateSeekerForm = () => {
    let isValid = true
    const newErrors = {
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      password: "",
    }

    if (!seekerData.firstName) {
      newErrors.firstName = "First name is required"
      isValid = false
    }

    if (!seekerData.lastName) {
      newErrors.lastName = "Last name is required"
      isValid = false
    }

    if (!seekerData.email) {
      newErrors.email = "Email is required"
      isValid = false
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(seekerData.email)) {
      newErrors.email = "Invalid email format"
      isValid = false
    }

    if (!seekerData.phone) {
      newErrors.phone = "Phone is required"
      isValid = false
    }

    if (!seekerData.password) {
      newErrors.password = "Password is required"
      isValid = false
    } else if (seekerData.password.length < 6) {
      newErrors.password = "Password must be at least 6 characters"
      isValid = false
    }

    setSeekerErrors(newErrors)
    return isValid
  }

  const validateCompanyForm = () => {
    let isValid = true
    const newErrors = {
      companyName: "",
      industry: "",
      companySize: "",
      contactName: "",
      contactEmail: "",
      phone: "",
      password: "",
    }

    if (!companyData.companyName) {
      newErrors.companyName = "Company name is required"
      isValid = false
    }

    if (!companyData.industry) {
      newErrors.industry = "Industry is required"
      isValid = false
    }

    if (!companyData.companySize) {
      newErrors.companySize = "Company size is required"
      isValid = false
    }

    if (!companyData.contactName) {
      newErrors.contactName = "Contact name is required"
      isValid = false
    }

    if (!companyData.contactEmail) {
      newErrors.contactEmail = "Email is required"
      isValid = false
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(companyData.contactEmail)) {
      newErrors.contactEmail = "Invalid email format"
      isValid = false
    }

    if (!companyData.phone) {
      newErrors.phone = "Phone is required"
      isValid = false
    }

    if (!companyData.password) {
      newErrors.password = "Password is required"
      isValid = false
    } else if (companyData.password.length < 6) {
      newErrors.password = "Password must be at least 6 characters"
      isValid = false
    }

    setCompanyErrors(newErrors)
    return isValid
  }

  const handleRegister = async (e: React.FormEvent, userType: "seeker" | "company") => {
    e.preventDefault()

    if (userType === "seeker") {
      if (!validateSeekerForm()) {
        return
      }
    } else {
      if (!validateCompanyForm()) {
        return
      }
    }

    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      setIsLoading(false)
      toast({
        title: "Account Created Successfully! 🎉",
        description: `Welcome to CareerBoost! Your ${userType} account is ready.`,
      })

      if (userType === "seeker") {
        router.push("/dashboard/seeker")
      } else {
        router.push("/dashboard/company")
      }
    }, 2000)
  }

  const benefits = [
    { icon: Sparkles, text: "AI-powered job matching", color: "text-orange-500" },
    { icon: Users, text: "Connect with top companies", color: "text-red-500" },
    { icon: CheckCircle, text: "Free forever", color: "text-green-500" },
    { icon: Star, text: "Premium support", color: "text-yellow-500" },
  ]

  const stats = [
    { icon: Award, value: "500K+", label: "Success Stories", color: "text-orange-600" },
    { icon: TrendingUp, value: "165%", label: "Avg Salary Increase", color: "text-red-600" },
    { icon: Building2, value: "15K+", label: "Top Companies", color: "text-yellow-600" },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-red-50">
      {/* Background Pattern */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-orange-400/20 rounded-full blur-3xl animate-pulse"></div>
        <div
          className="absolute -bottom-40 -left-40 w-80 h-80 bg-red-400/20 rounded-full blur-3xl animate-pulse"
          style={{ animationDelay: "2s" }}
        ></div>
        <div
          className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-yellow-400/10 rounded-full blur-3xl animate-pulse"
          style={{ animationDelay: "4s" }}
        ></div>
      </div>

      <div className="relative z-10 container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center space-x-3 mb-8 group">
            <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-red-500 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
              <Briefcase className="h-6 w-6 text-white" />
            </div>
            <span className="text-2xl font-bold bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">
              CareerBoost
            </span>
          </Link>

          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-gray-900">Start Your Success Story</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Join 500,000+ professionals who transformed their careers. Create your free account today.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 max-w-7xl mx-auto">
          {/* Left Side - Benefits & Testimonial */}
          <div className="space-y-8">
            {/* Hero Image */}
            <div className="relative rounded-3xl overflow-hidden shadow-2xl">
              <Image
                src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=600&h=400&fit=crop"
                alt="Team collaboration"
                width={600}
                height={400}
                className="w-full h-80 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
              <div className="absolute bottom-6 left-6 text-white">
                <h3 className="text-2xl font-bold mb-2">Join the Success Revolution</h3>
                <p className="text-white/90">Connect with amazing opportunities worldwide</p>
              </div>
            </div>

            {/* Benefits */}
            <Card className="border-0 shadow-xl bg-white/80 backdrop-blur-sm">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold mb-6 text-gray-900">Why Choose CareerBoost?</h3>
                <div className="grid grid-cols-2 gap-6">
                  {benefits.map((benefit, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-orange-100 to-red-100 rounded-xl flex items-center justify-center">
                        <benefit.icon className={`h-5 w-5 ${benefit.color}`} />
                      </div>
                      <span className="font-medium text-gray-700">{benefit.text}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4">
              {stats.map((stat, index) => (
                <div key={index} className="text-center p-4 bg-white/80 backdrop-blur-sm rounded-2xl shadow-lg">
                  <stat.icon className={`h-8 w-8 ${stat.color} mx-auto mb-2`} />
                  <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </div>
              ))}
            </div>

            {/* Testimonial */}
            <Card className="border-0 shadow-xl bg-white/80 backdrop-blur-sm">
              <CardContent className="p-8">
                <div className="flex items-center space-x-4 mb-4">
                  <Image
                    src="https://images.unsplash.com/photo-1494790108755-2616b612b786?w=60&h=60&fit=crop&crop=face"
                    alt="Sarah Johnson"
                    width={60}
                    height={60}
                    className="rounded-full"
                  />
                  <div>
                    <h4 className="font-semibold text-gray-900">Sarah Johnson</h4>
                    <p className="text-sm text-gray-600">Software Engineer at Google</p>
                  </div>
                </div>
                <blockquote className="text-gray-700 italic">
                  "CareerBoost helped me land my dream job at Google in just 2 weeks. The AI matching is incredibly
                  accurate!"
                </blockquote>
                <div className="flex text-yellow-400 mt-3">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-current" />
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Side - Registration Form */}
          <div className="flex items-center justify-center">
            <Card className="w-full max-w-md border-0 shadow-2xl bg-white/90 backdrop-blur-sm">
              <CardHeader className="text-center pb-2">
                <CardTitle className="text-2xl font-bold text-gray-900">Create Your Account</CardTitle>
                <CardDescription className="text-lg text-gray-600">
                  Choose your account type to get started
                </CardDescription>
              </CardHeader>

              <CardContent className="p-8">
                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                  <TabsList className="grid w-full grid-cols-2 mb-8 bg-gray-100">
                    <TabsTrigger
                      value="seeker"
                      className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white font-semibold"
                    >
                      <User className="h-4 w-4 mr-2" />
                      Job Seeker
                    </TabsTrigger>
                    <TabsTrigger
                      value="company"
                      className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white font-semibold"
                    >
                      <Building2 className="h-4 w-4 mr-2" />
                      Company
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="seeker">
                    <form onSubmit={(e) => handleRegister(e, "seeker")} className="space-y-6">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="firstName" className="text-gray-700 font-medium">
                            First Name *
                          </Label>
                          <Input
                            id="firstName"
                            placeholder="John"
                            value={seekerData.firstName}
                            onChange={(e) => setSeekerData({ ...seekerData, firstName: e.target.value })}
                            className="h-11 border-gray-200 focus:border-orange-500 focus:ring-orange-500"
                            required
                          />
                          {seekerErrors.firstName && <p className="text-red-500 text-sm">{seekerErrors.firstName}</p>}
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="lastName" className="text-gray-700 font-medium">
                            Last Name *
                          </Label>
                          <Input
                            id="lastName"
                            placeholder="Doe"
                            value={seekerData.lastName}
                            onChange={(e) => setSeekerData({ ...seekerData, lastName: e.target.value })}
                            className="h-11 border-gray-200 focus:border-orange-500 focus:ring-orange-500"
                            required
                          />
                          {seekerErrors.lastName && <p className="text-red-500 text-sm">{seekerErrors.lastName}</p>}
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="email" className="text-gray-700 font-medium">
                          Email Address *
                        </Label>
                        <div className="relative">
                          <Mail className="absolute left-3 top-3.5 h-4 w-4 text-gray-400" />
                          <Input
                            id="email"
                            type="email"
                            placeholder="john@example.com"
                            className="pl-10 h-11 border-gray-200 focus:border-orange-500 focus:ring-orange-500"
                            value={seekerData.email}
                            onChange={(e) => setSeekerData({ ...seekerData, email: e.target.value })}
                            required
                          />
                        </div>
                        {seekerErrors.email && <p className="text-red-500 text-sm">{seekerErrors.email}</p>}
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="phone" className="text-gray-700 font-medium">
                          Phone Number *
                        </Label>
                        <div className="relative">
                          <Phone className="absolute left-3 top-3.5 h-4 w-4 text-gray-400" />
                          <Input
                            id="phone"
                            type="tel"
                            placeholder="+1 (555) 123-4567"
                            className="pl-10 h-11 border-gray-200 focus:border-orange-500 focus:ring-orange-500"
                            value={seekerData.phone}
                            onChange={(e) => setSeekerData({ ...seekerData, phone: e.target.value })}
                            required
                          />
                        </div>
                        {seekerErrors.phone && <p className="text-red-500 text-sm">{seekerErrors.phone}</p>}
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="jobTitle" className="text-gray-700 font-medium">
                            Current/Desired Role
                          </Label>
                          <Input
                            id="jobTitle"
                            placeholder="Software Engineer"
                            value={seekerData.jobTitle}
                            onChange={(e) => setSeekerData({ ...seekerData, jobTitle: e.target.value })}
                            className="h-11 border-gray-200 focus:border-orange-500 focus:ring-orange-500"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="experience" className="text-gray-700 font-medium">
                            Experience Level
                          </Label>
                          <Select
                            value={seekerData.experience}
                            onValueChange={(value) => setSeekerData({ ...seekerData, experience: value })}
                          >
                            <SelectTrigger className="h-11 border-gray-200 focus:border-orange-500 focus:ring-orange-500">
                              <SelectValue placeholder="Select level" />
                            </SelectTrigger>
                            <SelectContent>
                              {experienceLevels.map((level) => (
                                <SelectItem key={level} value={level}>
                                  {level}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="location" className="text-gray-700 font-medium">
                          Location
                        </Label>
                        <div className="relative">
                          <MapPin className="absolute left-3 top-3.5 h-4 w-4 text-gray-400" />
                          <Input
                            id="location"
                            placeholder="San Francisco, CA"
                            className="pl-10 h-11 border-gray-200 focus:border-orange-500 focus:ring-orange-500"
                            value={seekerData.location}
                            onChange={(e) => setSeekerData({ ...seekerData, location: e.target.value })}
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="password" className="text-gray-700 font-medium">
                          Password *
                        </Label>
                        <div className="relative">
                          <Input
                            id="password"
                            type={showPassword ? "text" : "password"}
                            placeholder="Create a strong password"
                            className="pr-10 h-11 border-gray-200 focus:border-orange-500 focus:ring-orange-500"
                            value={seekerData.password}
                            onChange={(e) => setSeekerData({ ...seekerData, password: e.target.value })}
                            required
                          />
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                            onClick={() => setShowPassword(!showPassword)}
                          >
                            {showPassword ? (
                              <EyeOff className="h-4 w-4 text-gray-400" />
                            ) : (
                              <Eye className="h-4 w-4 text-gray-400" />
                            )}
                          </Button>
                        </div>
                        {seekerErrors.password && <p className="text-red-500 text-sm">{seekerErrors.password}</p>}
                      </div>

                      <div className="space-y-4">
                        <div className="flex items-center space-x-2">
                          <Checkbox
                            id="terms-seeker"
                            checked={seekerData.agreeToTerms}
                            onCheckedChange={(checked) =>
                              setSeekerData({ ...seekerData, agreeToTerms: checked as boolean })
                            }
                            required
                          />
                          <Label htmlFor="terms-seeker" className="text-sm text-gray-600">
                            I agree to the{" "}
                            <Link href="/terms" className="text-orange-600 hover:text-orange-700 font-medium">
                              Terms of Service
                            </Link>{" "}
                            and{" "}
                            <Link href="/privacy" className="text-orange-600 hover:text-orange-700 font-medium">
                              Privacy Policy
                            </Link>
                          </Label>
                        </div>

                        <div className="flex items-center space-x-2">
                          <Checkbox
                            id="newsletter-seeker"
                            checked={seekerData.subscribeNewsletter}
                            onCheckedChange={(checked) =>
                              setSeekerData({ ...seekerData, subscribeNewsletter: checked as boolean })
                            }
                          />
                          <Label htmlFor="newsletter-seeker" className="text-sm text-gray-600">
                            Subscribe to job alerts and career tips
                          </Label>
                        </div>
                      </div>

                      <Button
                        type="submit"
                        className="w-full h-12 bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white font-semibold shadow-lg"
                        disabled={isLoading}
                      >
                        {isLoading ? (
                          <div className="flex items-center">
                            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                            Creating Account...
                          </div>
                        ) : (
                          <>
                            Create Job Seeker Account
                            <ArrowRight className="ml-2 h-4 w-4" />
                          </>
                        )}
                      </Button>
                    </form>
                  </TabsContent>

                  <TabsContent value="company">
                    <form onSubmit={(e) => handleRegister(e, "company")} className="space-y-6">
                      <div className="space-y-2">
                        <Label htmlFor="companyName" className="text-gray-700 font-medium">
                          Company Name *
                        </Label>
                        <div className="relative">
                          <Building2 className="absolute left-3 top-3.5 h-4 w-4 text-gray-400" />
                          <Input
                            id="companyName"
                            placeholder="Acme Corporation"
                            className="pl-10 h-11 border-gray-200 focus:border-orange-500 focus:ring-orange-500"
                            value={companyData.companyName}
                            onChange={(e) => setCompanyData({ ...companyData, companyName: e.target.value })}
                            required
                          />
                        </div>
                        {companyErrors.companyName && (
                          <p className="text-red-500 text-sm">{companyErrors.companyName}</p>
                        )}
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="industry" className="text-gray-700 font-medium">
                            Industry *
                          </Label>
                          <Select
                            value={companyData.industry}
                            onValueChange={(value) => setCompanyData({ ...companyData, industry: value })}
                          >
                            <SelectTrigger className="h-11 border-gray-200 focus:border-orange-500 focus:ring-orange-500">
                              <SelectValue placeholder="Select industry" />
                            </SelectTrigger>
                            <SelectContent>
                              {industries.map((industry) => (
                                <SelectItem key={industry} value={industry}>
                                  {industry}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          {companyErrors.industry && <p className="text-red-500 text-sm">{companyErrors.industry}</p>}
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="companySize" className="text-gray-700 font-medium">
                            Company Size *
                          </Label>
                          <Select
                            value={companyData.companySize}
                            onValueChange={(value) => setCompanyData({ ...companyData, companySize: value })}
                          >
                            <SelectTrigger className="h-11 border-gray-200 focus:border-orange-500 focus:ring-orange-500">
                              <SelectValue placeholder="Select size" />
                            </SelectTrigger>
                            <SelectContent>
                              {companySizes.map((size) => (
                                <SelectItem key={size} value={size}>
                                  {size}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          {companyErrors.companySize && (
                            <p className="text-red-500 text-sm">{companyErrors.companySize}</p>
                          )}
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="website" className="text-gray-700 font-medium">
                          Company Website
                        </Label>
                        <div className="relative">
                          <Globe className="absolute left-3 top-3.5 h-4 w-4 text-gray-400" />
                          <Input
                            id="website"
                            type="url"
                            placeholder="https://company.com"
                            className="pl-10 h-11 border-gray-200 focus:border-orange-500 focus:ring-orange-500"
                            value={companyData.website}
                            onChange={(e) => setCompanyData({ ...companyData, website: e.target.value })}
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="contactName" className="text-gray-700 font-medium">
                          Contact Person *
                        </Label>
                        <div className="relative">
                          <User className="absolute left-3 top-3.5 h-4 w-4 text-gray-400" />
                          <Input
                            id="contactName"
                            placeholder="Jane Smith"
                            className="pl-10 h-11 border-gray-200 focus:border-orange-500 focus:ring-orange-500"
                            value={companyData.contactName}
                            onChange={(e) => setCompanyData({ ...companyData, contactName: e.target.value })}
                            required
                          />
                        </div>
                        {companyErrors.contactName && (
                          <p className="text-red-500 text-sm">{companyErrors.contactName}</p>
                        )}
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="contactEmail" className="text-gray-700 font-medium">
                          Contact Email *
                        </Label>
                        <div className="relative">
                          <Mail className="absolute left-3 top-3.5 h-4 w-4 text-gray-400" />
                          <Input
                            id="contactEmail"
                            type="email"
                            placeholder="hr@company.com"
                            className="pl-10 h-11 border-gray-200 focus:border-orange-500 focus:ring-orange-500"
                            value={companyData.contactEmail}
                            onChange={(e) => setCompanyData({ ...companyData, contactEmail: e.target.value })}
                            required
                          />
                        </div>
                        {companyErrors.contactEmail && (
                          <p className="text-red-500 text-sm">{companyErrors.contactEmail}</p>
                        )}
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="companyPhone" className="text-gray-700 font-medium">
                          Phone Number *
                        </Label>
                        <div className="relative">
                          <Phone className="absolute left-3 top-3.5 h-4 w-4 text-gray-400" />
                          <Input
                            id="companyPhone"
                            type="tel"
                            placeholder="+1 (555) 123-4567"
                            className="pl-10 h-11 border-gray-200 focus:border-orange-500 focus:ring-orange-500"
                            value={companyData.phone}
                            onChange={(e) => setCompanyData({ ...companyData, phone: e.target.value })}
                            required
                          />
                        </div>
                        {companyErrors.phone && <p className="text-red-500 text-sm">{companyErrors.phone}</p>}
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="companyLocation" className="text-gray-700 font-medium">
                          Company Location
                        </Label>
                        <div className="relative">
                          <MapPin className="absolute left-3 top-3.5 h-4 w-4 text-gray-400" />
                          <Input
                            id="companyLocation"
                            placeholder="San Francisco, CA"
                            className="pl-10 h-11 border-gray-200 focus:border-orange-500 focus:ring-orange-500"
                            value={companyData.location}
                            onChange={(e) => setCompanyData({ ...companyData, location: e.target.value })}
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="companyPassword" className="text-gray-700 font-medium">
                          Password *
                        </Label>
                        <div className="relative">
                          <Input
                            id="companyPassword"
                            type={showPassword ? "text" : "password"}
                            placeholder="Create a strong password"
                            className="pr-10 h-11 border-gray-200 focus:border-orange-500 focus:ring-orange-500"
                            value={companyData.password}
                            onChange={(e) => setCompanyData({ ...companyData, password: e.target.value })}
                            required
                          />
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                            onClick={() => setShowPassword(!showPassword)}
                          >
                            {showPassword ? (
                              <EyeOff className="h-4 w-4 text-gray-400" />
                            ) : (
                              <Eye className="h-4 w-4 text-gray-400" />
                            )}
                          </Button>
                        </div>
                        {companyErrors.password && <p className="text-red-500 text-sm">{companyErrors.password}</p>}
                      </div>

                      <div className="space-y-4">
                        <div className="flex items-center space-x-2">
                          <Checkbox
                            id="terms-company"
                            checked={companyData.agreeToTerms}
                            onCheckedChange={(checked) =>
                              setCompanyData({ ...companyData, agreeToTerms: checked as boolean })
                            }
                            required
                          />
                          <Label htmlFor="terms-company" className="text-sm text-gray-600">
                            I agree to the{" "}
                            <Link href="/terms" className="text-orange-600 hover:text-orange-700 font-medium">
                              Terms of Service
                            </Link>{" "}
                            and{" "}
                            <Link href="/privacy" className="text-orange-600 hover:text-orange-700 font-medium">
                              Privacy Policy
                            </Link>
                          </Label>
                        </div>

                        <div className="flex items-center space-x-2">
                          <Checkbox
                            id="newsletter-company"
                            checked={companyData.subscribeNewsletter}
                            onCheckedChange={(checked) =>
                              setCompanyData({ ...companyData, subscribeNewsletter: checked as boolean })
                            }
                          />
                          <Label htmlFor="newsletter-company" className="text-sm text-gray-600">
                            Subscribe to hiring tips and product updates
                          </Label>
                        </div>
                      </div>

                      <Button
                        type="submit"
                        className="w-full h-12 bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white font-semibold shadow-lg"
                        disabled={isLoading}
                      >
                        {isLoading ? (
                          <div className="flex items-center">
                            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                            Creating Account...
                          </div>
                        ) : (
                          <>
                            Create Company Account
                            <ArrowRight className="ml-2 h-4 w-4" />
                          </>
                        )}
                      </Button>
                    </form>
                  </TabsContent>
                </Tabs>

                <div className="mt-8 text-center">
                  <p className="text-sm text-gray-600">
                    Already have an account?{" "}
                    <Link href="/login" className="text-orange-600 hover:text-orange-700 font-semibold">
                      Sign in here
                    </Link>
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
